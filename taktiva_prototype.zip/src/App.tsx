import { useEffect, useState, type FormEvent, type ReactNode } from "react"
import { isSupabaseConfigured, supabase } from "./lib/supabase"
import {
  ArrowLeft,
  ArrowRight,
  BarChart3,
  Bell,
  Bot,
  Bookmark,
  BookmarkCheck,
  BriefcaseBusiness,
  Check,
  CheckCircle2,
  ChevronDown,
  ChevronRight,
  Circle,
  Clock3,
  Code2,
  Compass,
  Download,
  Eye,
  EyeOff,
  FileText,
  GraduationCap,
  Heart,
  LayoutDashboard,
  Lightbulb,
  ListChecks,
  Lock,
  LogOut,
  MapPin,
  Menu,
  MessageCircle,
  Megaphone,
  Palette,
  Play,
  RotateCcw,
  Search,
  Send,
  Settings,
  ShieldCheck,
  SlidersHorizontal,
  Sparkles,
  Star,
  Target,
  TrendingUp,
  Trophy,
  User,
  WalletCards,
  X,
  Zap,
} from "lucide-react"

type PublicView = "landing" | "login" | "register" | "onboarding" | "reset-password"
type AppPage = "dashboard" | "majors" | "assessment" | "recommendations" | "careers" | "simulator" | "comparison" | "roadmap" | "saved" | "profile"

type StudentProfile = {
  name: string
  email: string
  school: string
  classLevel: string
  interests: string[]
  strengths: string[]
  aspirations: string[]
  location: string
  budget: string
}
type DemoAccount = { id: string; passwordHash: string; profile: StudentProfile }
const emptyProfile = (name = "", email = ""): StudentProfile => ({
  name, email, school: "", classLevel: "Kelas XII", interests: [], strengths: [],
  aspirations: [], location: "Belum ditentukan", budget: "Belum ditentukan",
})
async function hashPassword(value: string) {
  const bytes = new TextEncoder().encode(value)
  const digest = await crypto.subtle.digest("SHA-256", bytes)
  return Array.from(new Uint8Array(digest)).map((b) => b.toString(16).padStart(2, "0")).join("")
}

const heroPhoto =
  "https://images.unsplash.com/photo-1756973229712-af48b150e911?crop=entropy&cs=tinysrgb&fit=crop&fm=jpg&q=85&w=1200"


function usePS<T>(key: string, init: T) {
  const [v, setV] = useState<T>(() => {
    try {
      const r = localStorage.getItem("taktiva:" + key)
      return r ? (JSON.parse(r) as T) : init
    } catch {
      return init
    }
  })
  useEffect(() => {
    try {
      localStorage.setItem("taktiva:" + key, JSON.stringify(v))
    } catch {}
  }, [key, v])
  return [v, setV] as const
}

const cn = (...classes: Array<string | false | undefined>) =>
  classes.filter(Boolean).join(" ")

function Logo({ light = false }: { light?: boolean }) {
  return (
    <button
      className="flex items-center gap-2.5"
      onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
    >
      <span
        className={cn(
          "grid size-10 place-items-center rounded-xl",
          light ? "bg-white/15" : "bg-purple text-white",
        )}
      >
        <Sparkles size={20} strokeWidth={2.5} />
      </span>
      <span
        className={cn(
          "text-xl font-extrabold tracking-tight",
          light ? "text-white" : "text-navy",
        )}
      >
        taktiva
      </span>
    </button>
  )
}

function Button({
  children,
  variant = "primary",
  className,
  onClick,
  type = "button",
  disabled,
}: {
  children: ReactNode
  variant?: "primary" | "secondary" | "ghost" | "dark"
  className?: string
  onClick?: () => void
  type?: "button" | "submit"
  disabled?: boolean
}) {
  return (
    <button
      type={type}
      disabled={disabled}
      onClick={onClick}
      className={cn(
        "inline-flex min-h-11 items-center justify-center gap-2 rounded-xl px-5 text-sm font-bold transition-all focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-purple disabled:cursor-not-allowed disabled:opacity-50",
        variant === "primary" &&
          "bg-purple text-white shadow-lg shadow-purple/20 hover:-translate-y-0.5 hover:bg-purple-dark",
        variant === "secondary" &&
          "border border-slate-200 bg-white text-navy shadow-sm hover:border-purple/30 hover:bg-purple-pale",
        variant === "ghost" &&
          "text-slate-600 hover:bg-slate-100 hover:text-navy",
        variant === "dark" &&
          "bg-navy text-white shadow-lg hover:bg-navy-light",
        className,
      )}
    >
      {children}
    </button>
  )
}

function Badge({
  children,
  tone = "purple",
}: {
  children: ReactNode
  tone?: "purple" | "green" | "blue" | "amber"
}) {
  const tones = {
    purple: "bg-purple-pale text-purple",
    green: "bg-emerald-50 text-emerald-700",
    blue: "bg-blue-50 text-blue-700",
    amber: "bg-amber-50 text-amber-700",
  }
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1 rounded-full px-3 py-1 text-xs font-bold",
        tones[tone],
      )}
    >
      {children}
    </span>
  )
}

function Progress({
  value,
  className = "",
}: {
  value: number
  className?: string
}) {
  return (
    <div
      className={cn("h-2 overflow-hidden rounded-full bg-slate-100", className)}
    >
      <div
        className="h-full rounded-full bg-gradient-to-r from-purple to-violet-400 transition-all"
        style={{ width: `${value}%` }}
      />
    </div>
  )
}

function Landing({ go }: { go: (view: PublicView) => void }) {
  return (
    <div className="min-h-screen bg-white text-navy">
      <header className="sticky top-0 z-40 border-b border-slate-100 bg-white/90 backdrop-blur-xl">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-5 py-4 lg:px-8">
          <Logo />
          <nav className="hidden items-center gap-8 text-sm font-semibold text-slate-600 md:flex">
            <a href="#fitur" className="hover:text-purple">
              Fitur
            </a>
            <a href="#cara-kerja" className="hover:text-purple">
              Cara kerja
            </a>
            <a href="#cerita" className="hover:text-purple">
              Cerita siswa
            </a>
          </nav>
          <div className="flex gap-2">
            <Button
              variant="ghost"
              className="hidden sm:inline-flex"
              onClick={() => go("login")}
            >
              Masuk
            </Button>
            <Button onClick={() => go("register")}>
              Mulai gratis <ArrowRight size={16} />
            </Button>
          </div>
        </div>
      </header>

      <main>
        <section className="relative overflow-hidden">
          <div className="hero-orb left-[-8%] top-10 bg-blue-200" />
          <div className="hero-orb right-[-10%] top-0 bg-violet-200" />
          <div className="mx-auto grid max-w-7xl items-center gap-14 px-5 py-16 lg:grid-cols-[1.08fr_.92fr] lg:px-8 lg:py-24">
            <div className="relative z-10">
              <Badge>
                <Sparkles size={13} /> AI guidance yang berpihak pada pilihanmu
              </Badge>
              <h1 className="mt-6 max-w-3xl text-5xl font-extrabold leading-[1.04] tracking-[-0.04em] text-navy md:text-6xl lg:text-7xl">
                Temukan Arah,{" "}
                <span className="text-gradient">Wujudkan Masa Depan</span>
              </h1>
              <p className="mt-6 max-w-xl text-lg leading-8 text-slate-600">
                Kenali potensimu, jelajahi jurusan dan karier, lalu susun
                langkah nyata—berdasarkan data, minat, dan kondisi yang kamu
                punya.
              </p>
              <div className="mt-8 flex flex-col gap-3 sm:flex-row">
                <Button className="px-7 py-3.5" onClick={() => go("register")}>
                  Mulai Perjalananmu <ArrowRight size={18} />
                </Button>
                <Button
                  variant="secondary"
                  className="px-7 py-3.5"
                  onClick={() =>
                    document.getElementById("cara-kerja")?.scrollIntoView({
                      behavior: "smooth",
                      block: "start",
                    })
                  }
                >
                  <Play size={17} fill="currentColor" /> Lihat cara kerjanya
                </Button>
              </div>
              <div className="mt-8 flex flex-wrap gap-x-6 gap-y-2 text-sm font-medium text-slate-500">
                <span className="flex items-center gap-2">
                  <CheckCircle2 className="text-emerald-500" size={17} /> Gratis
                  untuk mulai
                </span>
                <span className="flex items-center gap-2">
                  <ShieldCheck className="text-blue-500" size={17} /> Datamu
                  tetap aman
                </span>
                <span className="flex items-center gap-2">
                  <Heart className="text-rose-500" size={17} /> Tanpa menghakimi
                  pilihan
                </span>
              </div>
            </div>
            <div className="relative mx-auto w-full max-w-lg">
              <div className="absolute -left-7 top-16 z-10 rounded-2xl bg-white p-4 shadow-xl">
                <div className="flex items-center gap-3">
                  <span className="grid size-10 place-items-center rounded-xl bg-emerald-50 text-emerald-600">
                    <Target size={20} />
                  </span>
                  <div>
                    <p className="text-xs text-slate-500">Kecocokan teratas</p>
                    <p className="font-extrabold text-navy">
                      Sistem Informasi · 92%
                    </p>
                  </div>
                </div>
              </div>
              <div className="overflow-hidden rounded-[2rem] border-[6px] border-white shadow-2xl shadow-navy/15">
                <img
                  src={heroPhoto}
                  alt="Pelajar Indonesia merayakan kelulusan dan menatap masa depan"
                  className="h-[520px] w-full object-cover object-[center_35%]"
                />
                <div className="absolute inset-x-2 bottom-2 rounded-b-[1.65rem] bg-gradient-to-t from-navy via-navy/70 to-transparent px-7 pb-7 pt-24 text-white">
                  <p className="text-sm text-white/70">Perjalanan Dinda</p>
                  <p className="mt-1 text-xl font-bold">
                    “Sekarang aku tahu harus mulai dari mana.”
                  </p>
                </div>
              </div>
              <div className="absolute -bottom-6 -right-4 rounded-2xl bg-navy p-4 text-white shadow-xl">
                <div className="flex items-center gap-3">
                  <span className="grid size-10 place-items-center rounded-xl bg-white/10">
                    <TrendingUp size={21} />
                  </span>
                  <div>
                    <p className="text-xs text-white/60">Roadmap berjalan</p>
                    <p className="font-extrabold">12 dari 30 hari</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section id="fitur" className="bg-soft-blue py-20">
          <div className="mx-auto max-w-7xl px-5 lg:px-8">
            <div className="mx-auto max-w-2xl text-center">
              <Badge tone="blue">DIRANCANG UNTUK KAMU</Badge>
              <h2 className="mt-4 text-3xl font-extrabold tracking-tight md:text-4xl">
                Bukan sekadar tes minat biasa
              </h2>
              <p className="mt-4 text-slate-600">
                Taktiva menghubungkan siapa dirimu hari ini dengan pilihan nyata
                yang bisa kamu ambil besok.
              </p>
            </div>
            <div className="mt-12 grid gap-5 md:grid-cols-3">
              {[
                [
                  Compass,
                  "Kenali dirimu",
                  "Asesmen ringan untuk memetakan minat, kekuatan akademik, dan nilai yang penting bagimu.",
                  "bg-purple-pale text-purple",
                ],
                [
                  SlidersHorizontal,
                  "Uji berbagai skenario",
                  "Lihat bagaimana anggaran, lokasi, dan kesiapan akademik memengaruhi pilihan pendidikan.",
                  "bg-blue-50 text-blue-600",
                ],
                [
                  ListChecks,
                  "Ubah insight jadi aksi",
                  "Dapatkan roadmap 30 hari yang realistis, personal, dan mudah kamu selesaikan.",
                  "bg-amber-50 text-amber-600",
                ],
              ].map(([Icon, title, copy, color]) => (
                <article
                  key={title as string}
                  className="card-hover rounded-3xl border border-white bg-white p-7 shadow-sm"
                >
                  <span
                    className={cn(
                      "grid size-12 place-items-center rounded-2xl",
                      color as string,
                    )}
                  >
                    <Icon size={23} />
                  </span>
                  <h3 className="mt-5 text-xl font-extrabold">
                    {title as string}
                  </h3>
                  <p className="mt-3 leading-7 text-slate-600">
                    {copy as string}
                  </p>
                  <button
                    onClick={() => go("register")}
                    className="mt-5 flex items-center gap-1 text-sm font-bold text-purple"
                  >
                    Pelajari lebih lanjut <ChevronRight size={16} />
                  </button>
                </article>
              ))}
            </div>
          </div>
        </section>

        <section id="cara-kerja" className="py-20">
          <div className="mx-auto max-w-6xl px-5 lg:px-8">
            <div className="grid gap-12 lg:grid-cols-[.8fr_1.2fr] lg:items-center">
              <div>
                <Badge>3 LANGKAH SEDERHANA</Badge>
                <h2 className="mt-4 text-4xl font-extrabold tracking-tight">
                  Dari bingung jadi punya arah.
                </h2>
                <p className="mt-4 leading-7 text-slate-600">
                  Tidak ada jawaban yang “salah”. Taktiva membantumu mengambil
                  keputusan lebih sadar, bukan memutuskan masa depanmu.
                </p>
                <Button className="mt-7" onClick={() => go("register")}>
                  Coba sekarang <ArrowRight size={17} />
                </Button>
              </div>
              <div className="space-y-4">
                {[
                  [
                    "01",
                    "Ceritakan tentang dirimu",
                    "Isi profil, minat, kekuatan, dan aspirasi dalam sekitar 8 menit.",
                  ],
                  [
                    "02",
                    "Eksplorasi rekomendasi",
                    "Bandingkan jurusan, kampus, biaya, dan jalur alternatif yang relevan.",
                  ],
                  [
                    "03",
                    "Jalankan roadmap-mu",
                    "Ambil langkah kecil setiap hari dan pantau progresmu dengan percaya diri.",
                  ],
                ].map(([num, title, copy]) => (
                  <div
                    key={num}
                    className="flex gap-5 rounded-2xl border border-slate-100 bg-white p-5 shadow-sm"
                  >
                    <span className="grid size-11 shrink-0 place-items-center rounded-xl bg-navy text-sm font-black text-white">
                      {num}
                    </span>
                    <div>
                      <h3 className="font-extrabold">{title}</h3>
                      <p className="mt-1 text-sm leading-6 text-slate-500">
                        {copy}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>

        <section
          id="cerita"
          className="mx-5 mb-20 rounded-[2rem] bg-navy py-16 text-white lg:mx-auto lg:max-w-7xl"
        >
          <div className="mx-auto max-w-5xl px-6 text-center">
            <div className="flex justify-center gap-1 text-amber-300">
              {Array.from({ length: 5 }).map((_, i) => (
                <Star key={i} size={17} fill="currentColor" />
              ))}
            </div>
            <blockquote className="mx-auto mt-6 max-w-3xl text-2xl font-bold leading-relaxed md:text-3xl">
              “Aku tadinya merasa harus ikut pilihan teman. Taktiva bikin aku
              berani melihat opsi yang benar-benar cocok dengan diriku.”
            </blockquote>
            <p className="mt-5 text-sm font-semibold text-white/70">
              Nadia Putri · Kelas XII, Bandung
            </p>
          </div>
        </section>
      </main>

      <footer className="border-t border-slate-100 bg-slate-50">
        <div className="mx-auto flex max-w-7xl flex-col gap-8 px-5 py-10 md:flex-row md:items-center md:justify-between lg:px-8">
          <div>
            <Logo />
            <p className="mt-3 text-sm text-slate-500">
              Pilihanmu, langkahmu, masa depanmu.
            </p>
          </div>
          <div className="flex flex-wrap gap-6 text-sm font-semibold text-slate-500">
            <a href="#fitur" className="transition-colors hover:text-purple">Tentang & fitur</a>
            <a href="#cara-kerja" className="transition-colors hover:text-purple">Cara kerja</a>
            <a href="#cerita" className="transition-colors hover:text-purple">Cerita siswa</a>
            <button
              type="button"
              onClick={() =>
                window.alert(
                  "Taktiva saat ini adalah prototipe demo. Hindari memasukkan data pribadi atau sensitif. Data progres disimpan di browser perangkat ini.",
                )
              }
              className="text-left transition-colors hover:text-purple"
            >
              Privasi & data
            </button>
          </div>
          <p className="text-sm text-slate-400">© 2026 Taktiva</p>
        </div>
      </footer>
    </div>
  )
}

function Auth({
  mode, go, onLogin, onRegister,
}: {
  mode: "login" | "register"
  go: (v: PublicView) => void
  onLogin: (email: string, password: string) => Promise<string | null>
  onRegister: (data: { name: string; email: string; password: string; school: string; classLevel: string }) => Promise<string | null>
}) {
  const [show, setShow] = useState(false)
  const [name, setName] = useState("")
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [school, setSchool] = useState("")
  const [classLevel, setClassLevel] = useState("Kelas XII")
  const [error, setError] = useState("")
  const [busy, setBusy] = useState(false)
  const [notice, setNotice] = useState("")
  const submit = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault(); setError(""); setNotice(""); setBusy(true)
    try {
      const message = mode === "login"
        ? await onLogin(email.trim().toLowerCase(), password)
        : await onRegister({ name: name.trim(), email: email.trim().toLowerCase(), password, school: school.trim(), classLevel })
      if (message?.startsWith("SUCCESS:")) setNotice(message.slice(8))
      else if (message) setError(message)
    } catch {
      setError("Terjadi kendala. Coba lagi sebentar, ya.")
    } finally { setBusy(false) }
  }
  return (
    <div className="grid min-h-screen bg-white lg:grid-cols-[.88fr_1.12fr]">
      <aside className="relative hidden overflow-hidden bg-navy p-12 text-white lg:flex lg:flex-col lg:justify-between">
        <div className="hero-orb -left-20 top-1/3 bg-purple opacity-30" />
        <Logo light />
        <div className="relative z-10 max-w-lg">
          <Badge><Sparkles size={13} /> Langkah kecil, arah yang lebih jelas</Badge>
          <h1 className="mt-6 text-5xl font-extrabold leading-tight tracking-tight">Masa depanmu tidak harus ditebak sendirian.</h1>
          <p className="mt-5 text-lg leading-8 text-white/65">Taktiva membantumu mengeksplorasi pilihan dengan tenang, objektif, dan sesuai realitasmu.</p>
        </div>
        <div className="relative z-10 flex items-center gap-3 text-sm text-white/60"><ShieldCheck size={18} /> Mode demo: akun disimpan di browser ini.</div>
      </aside>
      <main className="flex min-h-screen items-center justify-center px-5 py-10">
        <div className="w-full max-w-md">
          <div className="mb-10 flex items-center justify-between lg:hidden"><Logo /><button onClick={() => go("landing")} aria-label="Kembali ke beranda"><X /></button></div>
          <button onClick={() => go("landing")} className="mb-8 hidden items-center gap-2 text-sm font-bold text-slate-500 hover:text-navy lg:flex"><ArrowLeft size={16} /> Kembali ke beranda</button>
          <h2 className="text-3xl font-extrabold tracking-tight">{mode === "login" ? "Selamat datang kembali" : "Mulai perjalananmu"}</h2>
          <p className="mt-2 text-slate-500">{mode === "login" ? "Masuk untuk melanjutkan progresmu." : "Buat akun siswa gratis dalam beberapa langkah."}</p>
          <div className={cn("mt-5 rounded-xl border p-3 text-xs leading-5", isSupabaseConfigured ? "border-emerald-200 bg-emerald-50 text-emerald-900" : "border-amber-200 bg-amber-50 text-amber-900")}><strong>{isSupabaseConfigured ? "Akun online aktif." : "Mode demo lokal."}</strong> {isSupabaseConfigured ? "Akun dikelola oleh Supabase Auth. Gunakan email yang dapat kamu akses untuk verifikasi." : "Akun hanya tersimpan di browser ini. Atur VITE_SUPABASE_URL dan VITE_SUPABASE_ANON_KEY untuk mengaktifkan akun online."}</div>
          <button type="button" onClick={() => setNotice(isSupabaseConfigured ? "Login Google belum diaktifkan. Aktifkan provider Google di Supabase Authentication jika ingin menggunakannya." : "Login Google belum dihubungkan. Atur Supabase terlebih dahulu untuk autentikasi online.")} className="mt-5 flex min-h-12 w-full items-center justify-center gap-3 rounded-xl border border-slate-200 bg-white font-bold text-slate-700 shadow-sm hover:bg-slate-50"><span className="text-lg font-black text-blue-600">G</span> Lanjutkan dengan Google</button>
          <div className="my-6 flex items-center gap-3 text-xs text-slate-400"><span className="h-px flex-1 bg-slate-200" /> ATAU GUNAKAN EMAIL <span className="h-px flex-1 bg-slate-200" /></div>
          <form className="space-y-4" onSubmit={submit}>
            {mode === "register" && <label className="block"><span className="field-label">Nama lengkap</span><input required minLength={2} value={name} onChange={e => setName(e.target.value)} className="field" placeholder="Contoh: Nadia Ramadhani" autoComplete="name" /></label>}
            <label className="block"><span className="field-label">Email</span><input required type="email" value={email} onChange={e => setEmail(e.target.value)} className="field" placeholder="nama@email.com" autoComplete="email" /></label>
            <label className="block"><div className="flex justify-between"><span className="field-label">Kata sandi</span>{mode === "login" && <button type="button" onClick={async () => { if (isSupabaseConfigured && supabase && email.trim()) { const { error } = await supabase.auth.resetPasswordForEmail(email.trim().toLowerCase(), { redirectTo: window.location.origin }); setNotice(error ? error.message : "Jika email terdaftar, tautan reset kata sandi akan dikirim. Periksa kotak masuk dan spam.") } else { setNotice(isSupabaseConfigured ? "Masukkan email terlebih dahulu untuk menerima tautan reset kata sandi." : "Reset kata sandi online tersedia setelah Supabase dikonfigurasi.") } }} className="text-xs font-bold text-purple">Lupa kata sandi?</button>}</div><div className="relative"><input required minLength={mode === "register" ? 8 : 1} value={password} onChange={e => setPassword(e.target.value)} type={show ? "text" : "password"} className="field pr-12" placeholder={mode === "login" ? "Masukkan kata sandi" : "Min. 8 karakter"} autoComplete={mode === "login" ? "current-password" : "new-password"}/><button type="button" aria-label={show ? "Sembunyikan kata sandi" : "Tampilkan kata sandi"} onClick={() => setShow(!show)} className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400">{show ? <EyeOff size={18}/> : <Eye size={18}/>}</button></div></label>
            {mode === "register" && <><label className="block"><span className="field-label">Asal sekolah</span><input required value={school} onChange={e => setSchool(e.target.value)} className="field" placeholder="Nama sekolah" autoComplete="organization"/></label><label className="block"><span className="field-label">Kelas</span><select value={classLevel} onChange={e => setClassLevel(e.target.value)} className="field"><option>Kelas XII</option><option>Kelas XI</option><option>Gap year</option><option>Lulusan SMA/SMK</option></select></label><label className="flex gap-3 text-sm leading-6 text-slate-500"><input required type="checkbox" className="mt-1 size-4 accent-purple"/> Saya memahami kebijakan privasi dan penggunaan data Taktiva.</label></>}
            {error && <p role="alert" className="rounded-xl border border-rose-200 bg-rose-50 p-3 text-sm text-rose-700">{error}</p>}
            {notice && <p role="status" className="rounded-xl border border-blue-200 bg-blue-50 p-3 text-sm text-blue-800">{notice}</p>}
            <Button type="submit" disabled={busy} className="w-full py-3">{busy ? "Memproses..." : mode === "login" ? "Masuk ke Taktiva" : "Buat akun gratis"} <ArrowRight size={17}/></Button>
          </form>
          <p className="mt-6 text-center text-sm text-slate-500">{mode === "login" ? "Belum punya akun?" : "Sudah punya akun?"} <button onClick={() => go(mode === "login" ? "register" : "login")} className="font-bold text-purple">{mode === "login" ? "Daftar sekarang" : "Masuk"}</button></p>
        </div>
      </main>
    </div>
  )
}

function ResetPassword({ onUpdate, go }: { onUpdate: (password: string) => Promise<string | null>; go: (v: PublicView) => void }) {
  const [password, setPassword] = useState("")
  const [confirm, setConfirm] = useState("")
  const [message, setMessage] = useState("")
  const [busy, setBusy] = useState(false)
  const submit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault(); setMessage("")
    if (password.length < 8) { setMessage("Kata sandi minimal 8 karakter."); return }
    if (password !== confirm) { setMessage("Konfirmasi kata sandi belum sama."); return }
    setBusy(true)
    const error = await onUpdate(password)
    setBusy(false)
    if (error) setMessage(error)
  }
  return <main className="grid min-h-screen place-items-center bg-soft-blue p-5"><form onSubmit={submit} className="w-full max-w-md rounded-3xl border border-slate-100 bg-white p-7 shadow-xl"><Logo/><h1 className="mt-8 text-2xl font-extrabold">Buat kata sandi baru</h1><p className="mt-2 text-sm leading-6 text-slate-500">Gunakan kata sandi baru yang kuat dan tidak digunakan di akun lain.</p><label className="mt-6 block"><span className="field-label">Kata sandi baru</span><input required minLength={8} type="password" autoComplete="new-password" value={password} onChange={e=>setPassword(e.target.value)} className="field"/></label><label className="mt-4 block"><span className="field-label">Konfirmasi kata sandi</span><input required minLength={8} type="password" autoComplete="new-password" value={confirm} onChange={e=>setConfirm(e.target.value)} className="field"/></label>{message && <p role="status" className="mt-4 rounded-xl bg-rose-50 p-3 text-sm text-rose-700">{message}</p>}<Button type="submit" disabled={busy} className="mt-6 w-full">{busy ? "Menyimpan..." : "Simpan kata sandi baru"}</Button><button type="button" onClick={()=>go("login")} className="mt-4 w-full text-sm font-bold text-purple">Kembali ke login</button></form></main>
}

function Onboarding({ profile, saveProfile, finish }: { profile: StudentProfile; saveProfile: (p: StudentProfile) => Promise<string | null>; finish: () => void }) {
  const [step, setStep] = useState(1)
  const [saveError, setSaveError] = useState("")
  const [saving, setSaving] = useState(false)
  const [draft, setDraft] = useState<StudentProfile>(profile)
  const [selected, setSelected] = useState<string[]>([...profile.interests, ...profile.strengths, ...profile.aspirations, profile.location, profile.budget].filter(Boolean))
  const toggle = (v: string) => setSelected(current => current.includes(v) ? current.filter(x => x !== v) : [...current, v])
  const data = [
    { title: "Kenalan dulu, yuk!", copy: "Informasi ini membantu kami membuat rekomendasi yang lebih relevan.", items: ["Nama lengkap", "Asal sekolah", "Kelas & status"] },
    { title: "Apa yang membuatmu penasaran?", copy: "Pilih beberapa minat. Kamu bisa mengubahnya kapan saja.", items: ["Teknologi", "Bisnis & ekonomi", "Seni & desain", "Kesehatan", "Lingkungan", "Komunikasi"] },
    { title: "Pelajaran dan kekuatanmu", copy: "Pilih hal-hal yang terasa paling dekat denganmu.", items: ["Matematika", "Bahasa Inggris", "Informatika", "Biologi", "Memecahkan masalah", "Presentasi"] },
    { title: "Bayangkan masa depanmu", copy: "Belum yakin itu wajar. Pilih aspirasi yang ingin kamu eksplorasi.", items: ["Membangun produk digital", "Membantu banyak orang", "Punya bisnis sendiri", "Bekerja kreatif", "Meneliti hal baru", "Belum tahu"] },
    { title: "Sesuaikan dengan realitasmu", copy: "Agar saran kami lebih realistis dan dapat ditindaklanjuti.", items: ["< Rp5 juta/semester", "Rp5–15 juta/semester", "Rp15–30 juta/semester", "Fleksibel", "Bandung", "Jabodetabek", "Yogyakarta", "Di mana saja"] },
  ][step - 1]
  const complete = async () => {
    setSaving(true); setSaveError("")
    const budget = selected.find(x => x.includes("semester") || x === "Fleksibel") || "Belum ditentukan"
    const location = selected.find(x => ["Bandung", "Jabodetabek", "Yogyakarta", "Di mana saja"].includes(x)) || "Belum ditentukan"
    const error = await saveProfile({ ...draft, interests: selected.filter(x => ["Teknologi", "Bisnis & ekonomi", "Seni & desain", "Kesehatan", "Lingkungan", "Komunikasi"].includes(x)), strengths: selected.filter(x => ["Matematika", "Bahasa Inggris", "Informatika", "Biologi", "Memecahkan masalah", "Presentasi"].includes(x)), aspirations: selected.filter(x => ["Membangun produk digital", "Membantu banyak orang", "Punya bisnis sendiri", "Bekerja kreatif", "Meneliti hal baru", "Belum tahu"].includes(x)), budget, location })
    setSaving(false)
    if (error) { setSaveError(error); return }
    finish()
  }
  return <div className="min-h-screen bg-soft-blue"><header className="border-b border-slate-100 bg-white"><div className="mx-auto flex max-w-5xl items-center justify-between px-5 py-4"><Logo/><span className="text-sm font-bold text-slate-500">Langkah {step} dari 5</span></div></header><main className="mx-auto max-w-3xl px-5 py-10 md:py-16"><Progress value={step * 20}/><div className="mt-8 rounded-3xl border border-slate-100 bg-white p-6 shadow-xl shadow-navy/5 md:p-10"><Badge>PROFIL SISWA</Badge><h1 className="mt-4 text-3xl font-extrabold tracking-tight md:text-4xl">{data.title}</h1><p className="mt-3 text-slate-500">{data.copy}</p>
    {step === 1 ? <div className="mt-8 space-y-4"><label className="block"><span className="field-label">Nama lengkap</span><input required className="field" value={draft.name} onChange={e => setDraft({...draft, name:e.target.value})} placeholder="Nama lengkap"/></label><label className="block"><span className="field-label">Email</span><input className="field" value={draft.email} disabled/></label><label className="block"><span className="field-label">Asal sekolah</span><input required className="field" value={draft.school} onChange={e => setDraft({...draft, school:e.target.value})} placeholder="Nama sekolah"/></label><label className="block"><span className="field-label">Kelas & status</span><select className="field" value={draft.classLevel} onChange={e => setDraft({...draft, classLevel:e.target.value})}><option>Kelas XII</option><option>Kelas XI</option><option>Gap year</option><option>Lulusan SMA/SMK</option></select></label></div> : <div className="mt-8 grid gap-3 sm:grid-cols-2">{data.items.map(item => <button type="button" key={item} onClick={() => toggle(item)} className={cn("flex min-h-14 items-center justify-between rounded-xl border p-4 text-left text-sm font-bold transition", selected.includes(item) ? "border-purple bg-purple-pale text-purple" : "border-slate-200 text-slate-600 hover:border-purple/30")}>{item}{selected.includes(item) ? <CheckCircle2 size={19}/> : <Circle size={19} className="text-slate-300"/>}</button>)}</div>}
    {saveError && <p role="alert" className="mt-5 rounded-xl bg-rose-50 p-3 text-sm text-rose-700">{saveError}</p>}<div className="mt-10 flex items-center justify-between"><Button variant="ghost" disabled={step===1} onClick={() => setStep(step-1)}><ArrowLeft size={17}/> Kembali</Button><Button disabled={saving} onClick={() => { if (step === 1 && (!draft.name.trim() || !draft.school.trim())) return; if (step < 5) setStep(step+1); else void complete() }}>{saving ? "Menyimpan..." : step < 5 ? "Lanjutkan" : "Simpan profil & buka dashboard"} <ArrowRight size={17}/></Button></div></div><p className="mt-5 text-center text-xs text-slate-400"><Lock size={12} className="mr-1 inline"/> {isSupabaseConfigured ? "Profil disimpan ke akun online kamu." : "Mode demo: data tersimpan di browser ini saja."}</p></main></div>
}

const navItems: Array<[AppPage, string, typeof LayoutDashboard]> = [
  ["dashboard", "Dashboard", LayoutDashboard],
  ["majors", "Explore Jurusan", GraduationCap],
  ["careers", "Career Challenges", BriefcaseBusiness],
  ["simulator", "What-If Simulator", SlidersHorizontal],
  ["roadmap", "Roadmap Saya", ListChecks],
  ["saved", "Opsi Tersimpan", Bookmark],
  ["profile", "Profil & Pengaturan", User],
]

function Sidebar({
  page,
  setPage,
  open,
  close,
  openChat,
}: {
  page: AppPage
  setPage: (p: AppPage) => void
  open: boolean
  close: () => void
  openChat: () => void
}) {
  return (
    <>
      {open && (
        <button
          aria-label="Tutup menu"
          onClick={close}
          className="fixed inset-0 z-40 bg-navy/40 lg:hidden"
        />
      )}
      <aside
        className={cn(
          "fixed inset-y-0 left-0 z-50 flex w-72 flex-col bg-navy p-5 text-white transition-transform lg:translate-x-0",
          open ? "translate-x-0" : "-translate-x-full",
        )}
      >
        <div className="flex items-center justify-between">
          <Logo light />
          <button className="lg:hidden" onClick={close}>
            <X />
          </button>
        </div>
        <nav className="mt-10 flex-1 space-y-1">
          <p className="mb-3 px-3 text-[11px] font-extrabold tracking-[.16em] text-white/35">
            MENU UTAMA
          </p>
          {navItems.map(([id, label, Icon]) => (
            <button
              key={id}
              onClick={() => {
                setPage(id)
                close()
              }}
              className={cn(
                "flex w-full items-center gap-3 rounded-xl px-3.5 py-3 text-sm font-semibold transition",
                page === id
                  ? "bg-white text-navy shadow-lg"
                  : "text-white/65 hover:bg-white/8 hover:text-white",
              )}
            >
              <Icon size={19} /> {label}
              {id === "roadmap" && (
                <span className="ml-auto rounded-full bg-purple px-2 py-0.5 text-[10px] text-white">
                  4
                </span>
              )}
            </button>
          ))}
          <button
            onClick={() => {
              openChat()
              close()
            }}
            className="mt-3 flex w-full items-center gap-3 rounded-xl border border-white/10 bg-white/8 px-3.5 py-3 text-sm font-semibold text-white transition hover:bg-white/15"
          >
            <Bot size={19} className="text-violet-300" /> Taktiva AI
            <span className="ml-auto size-2 rounded-full bg-emerald-400" />
          </button>
        </nav>
        <div className="rounded-2xl bg-white/8 p-4">
          <div className="flex items-center gap-2 text-xs font-bold">
            <Sparkles size={15} className="text-violet-300" /> Profilmu 80%
            lengkap
          </div>
          <Progress value={80} className="mt-3 bg-white/10" />
          <button
            onClick={() => setPage("profile")}
            className="mt-3 text-xs font-bold text-violet-300"
          >
            Lengkapi profil →
          </button>
        </div>
      </aside>
    </>
  )
}

function Topbar({ page, menu, profile, openProfile }: { page: AppPage; menu: () => void; profile: StudentProfile; openProfile: () => void }) {
  const titles: Record<AppPage, [string, string]> = {
    dashboard: ["Dashboard", "Senin, 19 Mei 2025"],
    majors: ["Explore Jurusan", "Temukan program studi yang paling cocok"],
    assessment: ["Asesmen Minat & Kekuatan", "Kenali pola unik dalam dirimu"],
    recommendations: [
      "Rekomendasi Personal",
      "Disusun dari profil dan hasil asesmenmu",
    ],
    careers: ["Career Challenges", "Coba pengalaman mini sebelum memilih"],
    simulator: ["What-If Simulator", "Eksplorasi berbagai skenario pendidikan"],
    comparison: ["Perbandingan Program", "Bandingkan pilihan secara objektif"],
    roadmap: ["Roadmap Saya", "Rencana aksi 30 hari yang personal"],
    saved: ["Opsi Tersimpan", "Semua pilihan yang ingin kamu pertimbangkan"],
    profile: ["Profil & Pengaturan", "Kelola data dan preferensimu"],
  }
  return (
    <header className="sticky top-0 z-30 flex min-h-20 items-center justify-between border-b border-slate-100 bg-white/90 px-5 backdrop-blur-xl lg:px-8">
      <div className="flex items-center gap-3">
        <button
          onClick={menu}
          className="grid size-10 place-items-center rounded-xl border border-slate-200 lg:hidden"
        >
          <Menu size={20} />
        </button>
        <div>
          <h1 className="text-xl font-extrabold text-navy">
            {titles[page][0]}
          </h1>
          <p className="hidden text-xs text-slate-400 sm:block">
            {titles[page][1]}
          </p>
        </div>
      </div>
      <div className="flex items-center gap-3">
        <button className="relative grid size-10 place-items-center rounded-xl border border-slate-200 text-slate-500 hover:bg-slate-50">
          <Bell size={19} />
          <span className="absolute right-2 top-2 size-2 rounded-full border-2 border-white bg-rose-500" />
        </button>
        <button onClick={openProfile} aria-label="Buka profil dan pengaturan" className="flex items-center gap-3 rounded-xl py-1 pl-1 pr-2 hover:bg-slate-50">
          <span className="grid size-9 place-items-center rounded-xl bg-gradient-to-br from-purple to-violet-400 text-sm font-extrabold text-white">
            {(profile.name.trim().split(/\s+/).slice(0,2).map(part => part[0]?.toUpperCase() || "").join("")) || "TA"}
          </span>
          <span className="hidden text-left md:block">
            <span className="block text-sm font-extrabold text-navy">
              {profile.name || "Profil siswa"}
            </span>
            <span className="block text-[11px] text-slate-400">
              {profile.classLevel || "Siswa"}
            </span>
          </span>
          <ChevronDown size={15} className="hidden text-slate-400 md:block" />
        </button>
      </div>
    </header>
  )
}

function StatCard({
  icon: Icon,
  label,
  value,
  detail,
  tone,
}: {
  icon: typeof Target
  label: string
  value: string
  detail: string
  tone: string
}) {
  return (
    <div className="rounded-2xl border border-slate-100 bg-white p-5 shadow-sm">
      <div className="flex items-start justify-between">
        <span
          className={cn("grid size-11 place-items-center rounded-xl", tone)}
        >
          <Icon size={21} />
        </span>
        <ChevronRight size={18} className="text-slate-300" />
      </div>
      <p className="mt-4 text-xs font-semibold text-slate-400">{label}</p>
      <p className="mt-1 text-2xl font-extrabold text-navy">{value}</p>
      <p className="mt-1 text-xs text-slate-500">{detail}</p>
    </div>
  )
}

function Dashboard({ go }: { go: (p: AppPage) => void }) {
  return (
    <div className="space-y-7">
      <section className="overflow-hidden rounded-3xl bg-gradient-to-r from-navy to-indigo-900 p-6 text-white md:p-8">
        <div className="grid items-center gap-6 md:grid-cols-[1fr_auto]">
          <div>
            <Badge>
              <Sparkles size={13} /> SIAP LANJUTKAN?
            </Badge>
            <h2 className="mt-4 text-3xl font-extrabold">
              Selamat pagi, Nadia!
            </h2>
            <p className="mt-2 max-w-xl text-sm leading-6 text-white/60">
              Kamu makin dekat dengan pilihan yang tepat. Hari ini, coba
              selesaikan satu tantangan karier kecil.
            </p>
            <Button className="mt-5" onClick={() => go("careers")}>
              Lihat tantangan hari ini <ArrowRight size={16} />
            </Button>
          </div>
          <div className="hidden size-40 place-items-center rounded-full border border-white/10 bg-white/5 md:grid">
            <div className="text-center">
              <p className="text-4xl font-black">12</p>
              <p className="text-xs text-white/50">hari aktif</p>
            </div>
          </div>
        </div>
      </section>
      <section className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard
          icon={User}
          label="KELENGKAPAN PROFIL"
          value="80%"
          detail="2 langkah lagi"
          tone="bg-purple-pale text-purple"
        />
        <StatCard
          icon={Compass}
          label="EKSPLORASI KARIER"
          value="6 / 10"
          detail="Karier telah dilihat"
          tone="bg-blue-50 text-blue-600"
        />
        <StatCard
          icon={Bookmark}
          label="OPSI TERSIMPAN"
          value="8"
          detail="Jurusan & kampus"
          tone="bg-amber-50 text-amber-600"
        />
        <StatCard
          icon={ListChecks}
          label="ROADMAP 30 HARI"
          value="40%"
          detail="12 aktivitas selesai"
          tone="bg-emerald-50 text-emerald-600"
        />
      </section>
      <div className="grid gap-7 xl:grid-cols-[1.45fr_.75fr]">
        <section className="rounded-3xl border border-slate-100 bg-white p-6 shadow-sm">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-lg font-extrabold">
                Jurusan yang cocok untukmu
              </h3>
              <p className="mt-1 text-xs text-slate-400">
                Berdasarkan profil awalmu
              </p>
            </div>
            <button
              onClick={() => go("recommendations")}
              className="text-sm font-bold text-purple"
            >
              Lihat semua
            </button>
          </div>
          <div className="mt-5 space-y-3">
            {[
              ["Sistem Informasi", "Teknologi × Bisnis", 92, "bg-purple"],
              ["Teknik Industri", "Sistem × Optimasi", 87, "bg-blue-500"],
              [
                "Manajemen Bisnis Digital",
                "Strategi × Kreativitas",
                84,
                "bg-emerald-500",
              ],
            ].map(([name, tag, score, color]) => (
              <button
                key={name as string}
                onClick={() => go("recommendations")}
                className="group flex w-full items-center gap-4 rounded-2xl border border-slate-100 p-4 text-left hover:border-purple/20 hover:bg-purple-pale/30"
              >
                <span
                  className={cn(
                    "grid size-11 place-items-center rounded-xl text-white",
                    color as string,
                  )}
                >
                  <GraduationCap size={21} />
                </span>
                <div className="min-w-0 flex-1">
                  <p className="font-extrabold text-navy">{name as string}</p>
                  <p className="text-xs text-slate-400">{tag as string}</p>
                </div>
                <div className="text-right">
                  <p className="font-black text-purple">{score as number}%</p>
                  <p className="text-[10px] text-slate-400">kecocokan</p>
                </div>
                <ChevronRight
                  size={17}
                  className="text-slate-300 group-hover:text-purple"
                />
              </button>
            ))}
          </div>
        </section>
        <section className="rounded-3xl border border-slate-100 bg-white p-6 shadow-sm">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-extrabold">Agenda terdekat</h3>
            <button onClick={() => go("roadmap")}>
              <ChevronRight size={19} className="text-slate-400" />
            </button>
          </div>
          <div className="mt-5 space-y-5">
            {[
              ["20", "MEI", "Selesaikan asesmen minat", "10 menit"],
              ["22", "MEI", "Bandingkan 2 program studi", "15 menit"],
              ["25", "MEI", "Coba challenge data", "30 menit"],
            ].map(([date, month, title, time]) => (
              <div key={date} className="flex gap-3">
                <div className="w-12 rounded-xl bg-soft-blue py-2 text-center">
                  <p className="text-lg font-black text-navy">{date}</p>
                  <p className="text-[9px] font-bold text-blue-600">{month}</p>
                </div>
                <div>
                  <p className="text-sm font-bold text-navy">{title}</p>
                  <p className="mt-1 flex items-center gap-1 text-xs text-slate-400">
                    <Clock3 size={12} /> {time}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </section>
      </div>
      <section>
        <h3 className="text-lg font-extrabold">Mulai dari sini</h3>
        <div className="mt-4 grid gap-4 md:grid-cols-3">
          {[
            [
              assessmentIcon,
              "Temukan pola kekuatanmu",
              "Lanjutkan asesmen · 60%",
              "assessment",
            ],
            [
              SlidersHorizontal,
              "Uji skenario pilihan",
              "Sesuaikan biaya & lokasi",
              "simulator",
            ],
            [
              Code2,
              "Coba mini challenge",
              "Pemrograman pemula · 20 menit",
              "careers",
            ],
          ].map(([Icon, title, detail, target]) => (
            <button
              key={title as string}
              onClick={() => go(target as AppPage)}
              className="card-hover flex items-center gap-4 rounded-2xl border border-slate-100 bg-white p-5 text-left shadow-sm"
            >
              <span className="grid size-11 shrink-0 place-items-center rounded-xl bg-purple-pale text-purple">
                <Icon size={21} />
              </span>
              <div>
                <p className="font-extrabold">{title as string}</p>
                <p className="mt-1 text-xs text-slate-400">
                  {detail as string}
                </p>
              </div>
              <ArrowRight size={17} className="ml-auto text-slate-300" />
            </button>
          ))}
        </div>
      </section>
    </div>
  )
}

const assessmentIcon = Lightbulb

function Assessment({ done }: { done: () => void }) {
  const [q, setQ] = useState(0)
  const [answer, setAnswer] = useState<number | null>(null)
  const questions = [
    [
      "Saat mengerjakan tugas kelompok, peran mana yang paling natural untukmu?",
      [
        "Menyusun rencana dan membagi tugas",
        "Mencari ide unik dan sudut pandang baru",
        "Menganalisis data dan menemukan pola",
        "Menyampaikan hasil ke depan kelas",
      ],
    ],
    [
      "Ketika bertemu masalah yang sulit, kamu cenderung...",
      [
        "Membaginya jadi langkah-langkah kecil",
        "Bertanya dan berdiskusi dengan orang lain",
        "Mencoba beberapa cara sampai berhasil",
        "Mencari contoh lalu mengadaptasinya",
      ],
    ],
    [
      "Proyek mana yang paling membuatmu bersemangat?",
      [
        "Membuat aplikasi sederhana",
        "Merancang kampanye sosial",
        "Menganalisis tren penjualan",
        "Menyusun acara sekolah",
      ],
    ],
  ]
  return (
    <div className="mx-auto max-w-4xl py-3">
      <div className="mb-8 flex items-center justify-between">
        <Badge>
          PERTANYAAN {q + 1} DARI {questions.length}
        </Badge>
        <span className="text-sm font-black text-purple">
          {Math.round(((q + 1) / questions.length) * 100)}%
        </span>
      </div>
      <Progress value={((q + 1) / questions.length) * 100} />
      <div className="mt-8 rounded-3xl border border-slate-100 bg-white p-6 shadow-sm md:p-10">
        <p className="text-sm font-bold text-purple">
          Tidak ada jawaban benar atau salah
        </p>
        <h2 className="mt-3 max-w-2xl text-2xl font-extrabold leading-snug md:text-3xl">
          {questions[q][0]}
        </h2>
        <div className="mt-8 grid gap-3 md:grid-cols-2">
          {questions[q][1].map((item, i) => (
            <button
              key={item}
              onClick={() => setAnswer(i)}
              className={cn(
                "flex min-h-24 items-center gap-4 rounded-2xl border p-5 text-left font-semibold transition",
                answer === i
                  ? "border-purple bg-purple-pale text-purple ring-2 ring-purple/10"
                  : "border-slate-200 text-slate-600 hover:border-purple/40",
              )}
            >
              <span
                className={cn(
                  "grid size-8 shrink-0 place-items-center rounded-lg text-xs font-black",
                  answer === i
                    ? "bg-purple text-white"
                    : "bg-slate-100 text-slate-400",
                )}
              >
                {String.fromCharCode(65 + i)}
              </span>
              {item}
            </button>
          ))}
        </div>
        <div className="mt-8 flex justify-between">
          <Button
            variant="ghost"
            disabled={q === 0}
            onClick={() => {
              setQ(q - 1)
              setAnswer(null)
            }}
          >
            <ArrowLeft size={17} /> Sebelumnya
          </Button>
          <Button
            disabled={answer === null}
            onClick={() => {
              if (q < questions.length - 1) {
                setQ(q + 1)
                setAnswer(null)
              } else done()
            }}
          >
            {q === questions.length - 1 ? "Lihat hasil" : "Selanjutnya"}{" "}
            <ArrowRight size={17} />
          </Button>
        </div>
      </div>
      <p className="mt-5 text-center text-xs text-slate-400">
        Jawaban disimpan otomatis · Hasil adalah panduan eksplorasi, bukan
        prediksi mutlak.
      </p>
    </div>
  )
}

const majors = [
  {
    name: "Sistem Informasi",
    score: 92,
    desc: "Menggabungkan teknologi, proses bisnis, dan kemampuan memecahkan masalah.",
    skills: ["Analisis sistem", "Komunikasi", "Pemrograman dasar"],
    careers: "Business Analyst, Product Manager, IT Consultant",
    duration: "4 tahun",
    cost: "Rp8–18 jt/semester*",
  },
  {
    name: "Teknik Industri",
    score: 87,
    desc: "Merancang dan meningkatkan sistem kompleks agar lebih efektif dan manusiawi.",
    skills: ["Optimasi", "Statistika", "Kepemimpinan"],
    careers: "Process Engineer, Supply Chain Analyst, Consultant",
    duration: "4 tahun",
    cost: "Rp7–16 jt/semester*",
  },
  {
    name: "Bisnis Digital",
    score: 84,
    desc: "Membangun strategi dan produk bisnis dengan dukungan teknologi digital.",
    skills: ["Strategi", "Riset pasar", "Kreativitas"],
    careers: "Digital Strategist, Entrepreneur, Growth Analyst",
    duration: "3,5–4 tahun",
    cost: "Rp6–20 jt/semester*",
  },
]

function Recommendations({
  compare,
  askAI,
}: {
  compare: () => void
  askAI: (context: string) => void
}) {
  const [saved, setSaved] = usePS<string[]>("saved-majors", ["Sistem Informasi"])
  return (
    <div>
      <div className="rounded-3xl bg-gradient-to-r from-purple to-violet-500 p-6 text-white md:flex md:items-center md:justify-between md:p-8">
        <div>
          <Badge>
            <Sparkles size={13} /> HASIL PERSONAL UNTUK ALYA
          </Badge>
          <h2 className="mt-4 text-2xl font-extrabold">
            Tiga arah yang layak kamu eksplorasi
          </h2>
          <p className="mt-2 max-w-2xl text-sm text-white/70">
            Rekomendasi ini dibuat dari minat, kekuatan, dan preferensimu—bukan
            jaminan hasil karier.
          </p>
        </div>
        <div className="mt-5 flex gap-3 md:mt-0">
          <Button
            variant="secondary"
            onClick={() =>
              askAI(
                "Bantu aku membandingkan Sistem Informasi, Teknik Industri, dan Bisnis Digital.",
              )
            }
          >
            <Bot size={17} /> Tanya Taktiva AI
          </Button>
          <Button variant="secondary" onClick={compare}>
            <BarChart3 size={17} /> Bandingkan
          </Button>
        </div>
      </div>
      <div className="mt-6 grid gap-5 xl:grid-cols-3">
        {majors.map((m, i) => (
          <article
            key={m.name}
            className={cn(
              "relative rounded-3xl border bg-white p-6 shadow-sm",
              i === 0 ? "border-purple/30" : "border-slate-100",
            )}
          >
            {i === 0 && (
              <span className="absolute right-5 top-0 -translate-y-1/2 rounded-full bg-purple px-3 py-1 text-[10px] font-black text-white">
                PALING SESUAI
              </span>
            )}
            <div className="flex items-start justify-between">
              <span className="grid size-12 place-items-center rounded-2xl bg-purple-pale text-purple">
                <GraduationCap size={23} />
              </span>
              <button
                onClick={() =>
                  setSaved((s) =>
                    s.includes(m.name)
                      ? s.filter((x) => x !== m.name)
                      : [...s, m.name],
                  )
                }
                className="text-purple"
              >
                {saved.includes(m.name) ? (
                  <BookmarkCheck fill="currentColor" size={21} />
                ) : (
                  <Bookmark size={21} />
                )}
              </button>
            </div>
            <div className="mt-5 flex items-end justify-between">
              <h3 className="text-xl font-extrabold">{m.name}</h3>
              <div className="text-right">
                <span className="text-2xl font-black text-purple">
                  {m.score}%
                </span>
                <p className="text-[9px] text-slate-400">COCOK</p>
              </div>
            </div>
            <p className="mt-3 text-sm leading-6 text-slate-500">{m.desc}</p>
            <div className="mt-5 border-t border-slate-100 pt-5">
              <p className="mini-label">KETERAMPILAN UTAMA</p>
              <div className="mt-2 flex flex-wrap gap-2">
                {m.skills.map((s) => (
                  <Badge key={s} tone="blue">
                    {s}
                  </Badge>
                ))}
              </div>
            </div>
            <div className="mt-5 space-y-3 text-sm">
              <div className="flex gap-2 text-slate-600">
                <BriefcaseBusiness
                  size={16}
                  className="mt-0.5 shrink-0 text-purple"
                />
                <span>{m.careers}</span>
              </div>
              <div className="flex gap-2 text-slate-600">
                <Clock3 size={16} className="text-purple" />
                {m.duration}
              </div>
              <div className="flex gap-2 text-slate-600">
                <WalletCards size={16} className="text-purple" />
                {m.cost}
              </div>
            </div>
            <Button variant="secondary" className="mt-6 w-full">
              Lihat detail jurusan <ArrowRight size={16} />
            </Button>
          </article>
        ))}
      </div>
      <div className="mt-5 rounded-2xl border border-amber-100 bg-amber-50 p-4 text-xs leading-5 text-amber-800">
        <strong>* Perkiraan biaya.</strong> Nilai dapat berubah dan perlu
        diverifikasi di situs resmi institusi. Jalur alternatif yang bisa
        dipertimbangkan: D4 Sistem Informasi, bootcamp terkurasi, atau program
        vokasi.
      </div>
    </div>
  )
}

function Majors({ go }: { go: (p: AppPage) => void }) {
  const catalog = [
    { ...majors[0], category: "Teknologi", students: "12,4 rb peminat" },
    { ...majors[1], category: "Sains", students: "9,8 rb peminat" },
    { ...majors[2], category: "Bisnis", students: "10,1 rb peminat" },
    {
      ...majors[0],
      name: "Ilmu Komunikasi",
      score: 79,
      category: "Bisnis",
      desc: "Mempelajari strategi komunikasi, media, dan perilaku audiens.",
      skills: ["Komunikasi", "Riset", "Storytelling"],
      careers: "Public Relations, Content Strategist, Media Planner",
      students: "11,2 rb peminat",
    },
    {
      ...majors[1],
      name: "Desain Produk",
      score: 77,
      category: "Desain",
      desc: "Merancang produk yang berguna melalui riset pengguna dan eksplorasi visual.",
      skills: ["Design thinking", "Prototyping", "Empati"],
      careers: "Product Designer, UX Designer, Design Researcher",
      students: "5,7 rb peminat",
    },
    {
      ...majors[2],
      name: "Statistika",
      score: 75,
      category: "Sains",
      desc: "Mengolah data menjadi informasi untuk menjawab masalah nyata.",
      skills: ["Matematika", "Analisis data", "Logika"],
      careers: "Data Analyst, Statistician, Risk Analyst",
      students: "6,3 rb peminat",
    },
    {
      ...majors[0],
      name: "Kesehatan Masyarakat",
      score: 73,
      category: "Kesehatan",
      desc: "Mencegah masalah kesehatan dan meningkatkan kualitas hidup masyarakat.",
      skills: ["Riset", "Komunikasi", "Analisis"],
      careers: "Health Educator, Epidemiologist, Policy Analyst",
      students: "8,9 rb peminat",
    },
  ]
  const categories = [
    "Semua",
    "Teknologi",
    "Bisnis",
    "Kesehatan",
    "Desain",
    "Sains",
  ]
  const [query, setQuery] = useState("")
  const [category, setCategory] = useState("Semua")
  const [saved, setSaved] = usePS<string[]>("saved-majors", ["Sistem Informasi"])
  const [compare, setCompare] = useState<string[]>([])
  const [detail, setDetail] = useState<typeof catalog[number] | null>(null)
  const [showFilters, setShowFilters] = useState(false)
  const [sort, setSort] = useState("Kecocokan tertinggi")

  const results = catalog
    .filter((major) => category === "Semua" || major.category === category)
    .filter((major) => {
      const keyword = query.toLowerCase()
      return (
        major.name.toLowerCase().includes(keyword) ||
        major.desc.toLowerCase().includes(keyword) ||
        major.skills.some((skill) => skill.toLowerCase().includes(keyword))
      )
    })
    .sort((a, b) =>
      sort === "Nama A–Z" ? a.name.localeCompare(b.name) : b.score - a.score,
    )

  const toggleCompare = (name: string) =>
    setCompare((current) =>
      current.includes(name)
        ? current.filter((item) => item !== name)
        : current.length < 2
          ? [...current, name]
          : current,
    )

  return (
    <div>
      <div className="flex flex-col gap-4 md:flex-row md:items-center">
        <div className="relative flex-1">
          <Search
            className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400"
            size={19}
          />
          <input
            className="field pl-11"
            placeholder="Cari jurusan, keterampilan, atau bidang..."
            value={query}
            onChange={(event) => setQuery(event.target.value)}
          />
          {query && (
            <button
              aria-label="Hapus pencarian"
              onClick={() => setQuery("")}
              className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400 hover:text-navy"
            >
              <X size={17} />
            </button>
          )}
        </div>
        <Button
          variant="secondary"
          onClick={() => setShowFilters(!showFilters)}
        >
          <SlidersHorizontal size={17} /> Filter
          {(category !== "Semua" || sort !== "Kecocokan tertinggi") && (
            <span className="size-2 rounded-full bg-purple" />
          )}
        </Button>
        <Button onClick={() => go("assessment")}>
          <Lightbulb size={17} /> Mulai asesmen
        </Button>
      </div>
      {showFilters && (
        <div className="mt-4 flex flex-col gap-4 rounded-2xl border border-slate-100 bg-white p-4 shadow-sm sm:flex-row sm:items-end">
          <label className="flex-1">
            <span className="field-label">Urutkan hasil</span>
            <select
              className="field"
              value={sort}
              onChange={(event) => setSort(event.target.value)}
            >
              <option>Kecocokan tertinggi</option>
              <option>Nama A–Z</option>
            </select>
          </label>
          <div className="flex-1">
            <span className="field-label">Kecocokan minimum</span>
            <div className="flex min-h-12 items-center rounded-xl bg-slate-50 px-4 text-sm text-slate-500">
              Menampilkan rekomendasi di atas 70%
            </div>
          </div>
          <Button
            variant="ghost"
            onClick={() => {
              setCategory("Semua")
              setSort("Kecocokan tertinggi")
              setQuery("")
            }}
          >
            Reset filter
          </Button>
        </div>
      )}
      <div className="mt-6 flex gap-2 overflow-x-auto pb-2">
        {categories.map((item) => (
          <button
            key={item}
            onClick={() => setCategory(item)}
            className={cn(
              "rounded-full px-4 py-2 text-sm font-bold whitespace-nowrap",
              category === item
                ? "bg-navy text-white"
                : "border border-slate-200 bg-white text-slate-500",
            )}
          >
            {item}
          </button>
        ))}
      </div>
      <div className="mt-5 flex items-center justify-between">
        <p className="text-sm text-slate-500">
          <strong className="text-navy">{results.length} jurusan</strong>{" "}
          ditemukan
          {query && <> untuk “{query}”</>}
        </p>
        {saved.length > 0 && (
          <button
            onClick={() => go("saved")}
            className="flex items-center gap-2 text-xs font-bold text-purple"
          >
            <BookmarkCheck size={16} /> {saved.length} tersimpan
          </button>
        )}
      </div>
      {results.length > 0 ? (
        <div className="mt-4 grid gap-5 md:grid-cols-2 xl:grid-cols-3">
          {results.map((major) => (
            <article
              key={major.name}
              className={cn(
                "card-hover flex flex-col rounded-3xl border bg-white p-6 shadow-sm",
                compare.includes(major.name)
                  ? "border-purple ring-2 ring-purple/10"
                  : "border-slate-100",
              )}
            >
              <div className="flex justify-between">
                <span className="grid size-11 place-items-center rounded-xl bg-purple-pale text-purple">
                  <GraduationCap size={21} />
                </span>
                <button
                  aria-label={`Simpan ${major.name}`}
                  onClick={() =>
                    setSaved((current) =>
                      current.includes(major.name)
                        ? current.filter((item) => item !== major.name)
                        : [...current, major.name],
                    )
                  }
                  className={cn(
                    "grid size-9 place-items-center rounded-lg transition",
                    saved.includes(major.name)
                      ? "bg-purple-pale text-purple"
                      : "text-slate-300 hover:bg-slate-50 hover:text-purple",
                  )}
                >
                  {saved.includes(major.name) ? (
                    <BookmarkCheck size={20} fill="currentColor" />
                  ) : (
                    <Bookmark size={20} />
                  )}
                </button>
              </div>
              <div className="mt-5 flex items-center gap-2">
                <Badge tone="blue">{major.category}</Badge>
                <span className="text-[10px] text-slate-400">
                  {major.students}
                </span>
              </div>
              <h3 className="mt-3 text-lg font-extrabold">{major.name}</h3>
              <p className="mt-2 text-sm leading-6 text-slate-500">
                {major.desc}
              </p>
              <div className="mt-4 flex flex-wrap gap-2">
                {major.skills.slice(0, 3).map((skill) => (
                  <span
                    key={skill}
                    className="rounded-lg bg-slate-50 px-2.5 py-1 text-[10px] font-bold text-slate-500"
                  >
                    {skill}
                  </span>
                ))}
              </div>
              <div className="mt-auto flex items-center justify-between pt-5">
                <Badge>{major.score}% cocok</Badge>
                <button
                  onClick={() => setDetail(major)}
                  className="text-sm font-bold text-purple"
                >
                  Lihat detail →
                </button>
              </div>
              <label className="mt-4 flex cursor-pointer items-center gap-2 border-t border-slate-100 pt-4 text-xs font-bold text-slate-500">
                <input
                  type="checkbox"
                  checked={compare.includes(major.name)}
                  onChange={() => toggleCompare(major.name)}
                  disabled={
                    compare.length >= 2 && !compare.includes(major.name)
                  }
                  className="size-4 accent-purple"
                />
                Tambahkan ke perbandingan
              </label>
            </article>
          ))}
        </div>
      ) : (
        <div className="mt-5 grid min-h-80 place-items-center rounded-3xl border border-dashed border-slate-200 bg-white text-center">
          <div className="max-w-sm px-5">
            <span className="mx-auto grid size-14 place-items-center rounded-2xl bg-slate-100 text-slate-400">
              <Search size={24} />
            </span>
            <h3 className="mt-4 text-lg font-extrabold">
              Jurusan belum ditemukan
            </h3>
            <p className="mt-2 text-sm leading-6 text-slate-400">
              Coba gunakan kata kunci lain atau tampilkan kembali semua
              kategori.
            </p>
            <Button
              className="mt-5"
              onClick={() => {
                setQuery("")
                setCategory("Semua")
              }}
            >
              Tampilkan semua jurusan
            </Button>
          </div>
        </div>
      )}
      {compare.length > 0 && (
        <div className="sticky bottom-4 z-20 mx-auto mt-6 flex max-w-2xl flex-col gap-3 rounded-2xl border border-purple/20 bg-navy p-4 text-white shadow-2xl sm:flex-row sm:items-center">
          <div className="flex-1">
            <p className="text-sm font-extrabold">
              {compare.length} dari 2 jurusan dipilih
            </p>
            <p className="mt-1 truncate text-xs text-white/55">
              {compare.join(" · ")}
            </p>
          </div>
          <button
            onClick={() => setCompare([])}
            className="text-xs font-bold text-white/60"
          >
            Hapus
          </button>
          <Button
            disabled={compare.length < 2}
            onClick={() => go("comparison")}
          >
            Bandingkan sekarang <ArrowRight size={16} />
          </Button>
        </div>
      )}
      {detail && (
        <div className="fixed inset-0 z-50 flex items-end justify-center bg-navy/45 p-0 backdrop-blur-sm sm:items-center sm:p-5">
          <button
            aria-label="Tutup detail"
            onClick={() => setDetail(null)}
            className="absolute inset-0"
          />
          <section className="relative z-10 max-h-[92vh] w-full max-w-2xl overflow-y-auto rounded-t-3xl bg-white p-6 shadow-2xl sm:rounded-3xl sm:p-8">
            <div className="flex items-start justify-between">
              <span className="grid size-12 place-items-center rounded-2xl bg-purple-pale text-purple">
                <GraduationCap size={23} />
              </span>
              <button
                aria-label="Tutup"
                onClick={() => setDetail(null)}
                className="grid size-10 place-items-center rounded-xl bg-slate-100 text-slate-500"
              >
                <X size={19} />
              </button>
            </div>
            <Badge tone="blue">{detail.category}</Badge>
            <div className="mt-3 flex items-end justify-between gap-4">
              <h2 className="text-2xl font-extrabold">{detail.name}</h2>
              <span className="text-2xl font-black text-purple">
                {detail.score}%
              </span>
            </div>
            <p className="mt-3 text-sm leading-7 text-slate-500">
              {detail.desc}
            </p>
            <div className="mt-6 grid gap-3 sm:grid-cols-2">
              <div className="rounded-2xl bg-soft-blue p-4">
                <p className="mini-label">DURASI STUDI</p>
                <p className="mt-2 font-extrabold">{detail.duration}</p>
              </div>
              <div className="rounded-2xl bg-amber-50 p-4">
                <p className="mini-label">ESTIMASI BIAYA</p>
                <p className="mt-2 font-extrabold">{detail.cost}</p>
              </div>
            </div>
            <div className="mt-6">
              <p className="mini-label">KETERAMPILAN YANG DIPELAJARI</p>
              <div className="mt-3 flex flex-wrap gap-2">
                {detail.skills.map((skill) => (
                  <Badge key={skill} tone="blue">
                    {skill}
                  </Badge>
                ))}
              </div>
            </div>
            <div className="mt-6 rounded-2xl border border-slate-100 p-4">
              <p className="mini-label">PROSPEK KARIER</p>
              <p className="mt-2 text-sm font-semibold leading-6 text-slate-600">
                {detail.careers}
              </p>
            </div>
            <div className="mt-7 flex flex-col gap-3 sm:flex-row">
              <Button
                className="flex-1"
                onClick={() => {
                  setDetail(null)
                  go("recommendations")
                }}
              >
                Lihat rekomendasi lengkap <ArrowRight size={16} />
              </Button>
              <Button
                variant="secondary"
                onClick={() =>
                  setSaved((current) =>
                    current.includes(detail.name)
                      ? current.filter((item) => item !== detail.name)
                      : [...current, detail.name],
                  )
                }
              >
                {saved.includes(detail.name) ? (
                  <BookmarkCheck size={17} />
                ) : (
                  <Bookmark size={17} />
                )}
                {saved.includes(detail.name) ? "Tersimpan" : "Simpan"}
              </Button>
            </div>
          </section>
        </div>
      )}
    </div>
  )
}

function Simulator({ compare }: { compare: () => void }) {
  const [budget, setBudget] = usePS("sim-budget", 12)
  const [readiness, setReadiness] = usePS("sim-readiness", 72)
  const [location, setLocation] = usePS("sim-location", "Bandung")
  const second =
    budget > 18 ? "Universitas Swasta Unggulan" : "Politeknik Negeri"
  return (
    <div className="grid gap-6 xl:grid-cols-[.75fr_1.25fr]">
      <section className="rounded-3xl border border-slate-100 bg-white p-6 shadow-sm">
        <Badge>
          <SlidersHorizontal size={13} /> ATUR SKENARIO
        </Badge>
        <h2 className="mt-4 text-xl font-extrabold">
          Apa yang paling penting bagimu?
        </h2>
        <div className="mt-7 space-y-7">
          <label className="block">
            <div className="flex justify-between">
              <span className="field-label">Anggaran per semester</span>
              <strong className="text-sm text-purple">Rp{budget} juta</strong>
            </div>
            <input
              type="range"
              min="3"
              max="35"
              value={budget}
              onChange={(e) => setBudget(+e.target.value)}
              className="range"
            />
            <div className="mt-1 flex justify-between text-[10px] text-slate-400">
              <span>Rp3 jt</span>
              <span>Rp35 jt</span>
            </div>
          </label>
          <label className="block">
            <div className="flex justify-between">
              <span className="field-label">Kesiapan akademik</span>
              <strong className="text-sm text-purple">{readiness}%</strong>
            </div>
            <input
              type="range"
              min="40"
              max="100"
              value={readiness}
              onChange={(e) => setReadiness(+e.target.value)}
              className="range"
            />
          </label>
          <div>
            <span className="field-label">Minat utama</span>
            <div className="flex flex-wrap gap-2">
              {["Teknologi", "Bisnis", "Desain"].map((x, i) => (
                <button
                  key={x}
                  className={cn(
                    "rounded-xl border px-3 py-2 text-xs font-bold",
                    i < 2
                      ? "border-purple bg-purple-pale text-purple"
                      : "border-slate-200 text-slate-500",
                  )}
                >
                  {x}
                </button>
              ))}
            </div>
          </div>
          <label>
            <span className="field-label">Lokasi studi pilihan</span>
            <select
              className="field"
              value={location}
              onChange={(e) => setLocation(e.target.value)}
            >
              <option>Bandung</option>
              <option>Yogyakarta</option>
              <option>Jabodetabek</option>
              <option>Di mana saja</option>
            </select>
          </label>
        </div>
        <div className="mt-7 rounded-2xl bg-blue-50 p-4 text-xs leading-5 text-blue-800">
          <Lightbulb size={16} className="mb-2" />
          <strong>Mengapa hasil berubah?</strong>
          <br />
          Anggaran dan kesiapanmu mengubah prioritas antara biaya, peluang
          masuk, dan kedalaman kurikulum.
        </div>
      </section>
      <section>
        <div className="mb-4 flex items-center justify-between">
          <div>
            <h2 className="text-xl font-extrabold">Perbandingan skenario</h2>
            <p className="text-xs text-slate-400">
              Diperbarui langsung dari pilihanmu
            </p>
          </div>
          <Button variant="secondary" onClick={compare}>
            <BarChart3 size={16} /> Detail
          </Button>
        </div>
        <div className="grid gap-4 md:grid-cols-2">
          {[
            [
              "Pilihan seimbang",
              "S1 Sistem Informasi · PTN",
              "Rp8–12 jt",
              "Kompetitif",
              [
                "Kurikulum luas",
                `Tersedia di ${location}`,
                "Jaringan alumni kuat",
              ],
              "bg-purple",
            ],
            [
              "Jalur alternatif",
              second,
              budget > 18 ? "Rp16–24 jt" : "Rp5–9 jt",
              readiness > 80 ? "Cukup kompetitif" : "Lebih terjangkau",
              [
                "Lebih banyak praktik",
                "Siap kerja lebih cepat",
                "Pilihan beasiswa",
              ],
              "bg-blue-500",
            ],
          ].map(([label, title, cost, access, pros, color], i) => (
            <article
              key={label as string}
              className={cn(
                "rounded-3xl border bg-white p-6 shadow-sm",
                i === 0 ? "border-purple/30" : "border-slate-100",
              )}
            >
              <div className="flex justify-between">
                <Badge tone={i === 0 ? "purple" : "blue"}>
                  {label as string}
                </Badge>
                {i === 0 && (
                  <Star
                    size={18}
                    className="text-amber-400"
                    fill="currentColor"
                  />
                )}
              </div>
              <h3 className="mt-5 text-xl font-extrabold">{title as string}</h3>
              <div className="mt-5 grid grid-cols-2 gap-3">
                <div className="rounded-xl bg-slate-50 p-3">
                  <p className="mini-label">EST. BIAYA</p>
                  <p className="mt-1 text-sm font-black">{cost as string}</p>
                </div>
                <div className="rounded-xl bg-slate-50 p-3">
                  <p className="mini-label">PELUANG MASUK</p>
                  <p className="mt-1 text-sm font-black">{access as string}</p>
                </div>
              </div>
              <div className="mt-5 space-y-3">
                {(pros as string[]).map((p) => (
                  <p
                    key={p}
                    className="flex items-center gap-2 text-sm text-slate-600"
                  >
                    <CheckCircle2 size={16} className="text-emerald-500" />
                    {p}
                  </p>
                ))}
              </div>
              <div className={cn("mt-6 h-1.5 rounded-full", color as string)} />
            </article>
          ))}
        </div>
        <div className="mt-4 rounded-2xl border border-slate-100 bg-white p-5">
          <h3 className="font-extrabold">Trade-off utama</h3>
          <p className="mt-2 text-sm leading-6 text-slate-500">
            Skenario seimbang menawarkan fleksibilitas karier lebih luas,
            sedangkan jalur alternatif mengutamakan pengalaman praktik dan
            efisiensi biaya. Keduanya dapat menjadi pilihan baik sesuai
            prioritasmu.
          </p>
        </div>
      </section>
    </div>
  )
}

type Challenge = {
  id: string
  title: string
  area: string
  description: string
  difficulty: string
  duration: string
  skills: string[]
  icon: typeof Code2
  tone: string
  task: string
  hint: string
  majors: string[]
}

const careerChallenges: Challenge[] = [
  {
    id: "coding",
    title: "Bangun Logika Pertamamu",
    area: "Coding",
    description: "Susun logika untuk aplikasi pengingat tugas sekolah.",
    difficulty: "Pemula",
    duration: "20 menit",
    skills: ["Logika", "Problem solving"],
    icon: Code2,
    tone: "bg-purple-pale text-purple",
    task: "Urutkan langkah yang tepat agar aplikasi dapat mengingatkan tugas berdasarkan tenggat.",
    hint: "Mulai dari data yang perlu dimasukkan pengguna, lalu pikirkan kapan notifikasi harus muncul.",
    majors: ["Sistem Informasi", "Informatika", "Teknik Komputer"],
  },
  {
    id: "data",
    title: "Baca Cerita dari Data",
    area: "Data Analysis",
    description: "Temukan insight dari data penjualan kantin sekolah.",
    difficulty: "Pemula",
    duration: "30 menit",
    skills: ["Analisis", "Statistika"],
    icon: BarChart3,
    tone: "bg-blue-50 text-blue-600",
    task: "Dari data yang tersedia, pilih kesimpulan paling kuat dan jelaskan alasanmu.",
    hint: "Bandingkan jumlah penjualan, bukan hanya harga setiap produk.",
    majors: ["Statistika", "Sains Data", "Sistem Informasi"],
  },
  {
    id: "ux",
    title: "Desain Antrean Lebih Baik",
    area: "UI/UX Design",
    description: "Rancang alur pemesanan kantin yang lebih mudah digunakan.",
    difficulty: "Menengah",
    duration: "35 menit",
    skills: ["Empati", "Prototyping"],
    icon: Palette,
    tone: "bg-amber-50 text-amber-600",
    task: "Pilih masalah pengguna yang paling penting, lalu tulis solusi alur dalam tiga langkah.",
    hint: "Pikirkan siswa yang hanya punya waktu istirahat 15 menit.",
    majors: ["Desain Komunikasi Visual", "Desain Produk", "Sistem Informasi"],
  },
  {
    id: "marketing",
    title: "Kampanye yang Menggerakkan",
    area: "Digital Marketing",
    description: "Buat ide kampanye digital untuk acara sekolah.",
    difficulty: "Menengah",
    duration: "25 menit",
    skills: ["Copywriting", "Strategi konten"],
    icon: Megaphone,
    tone: "bg-rose-50 text-rose-600",
    task: "Tentukan audiens, pesan utama, dan kanal terbaik untuk promosi festival sekolah.",
    hint: "Pesan yang baik menjawab: mengapa audiens perlu peduli sekarang?",
    majors: ["Ilmu Komunikasi", "Bisnis Digital", "Manajemen"],
  },
  {
    id: "business",
    title: "Strategi Kedai Sekolah",
    area: "Business Strategy",
    description: "Pilih strategi pertumbuhan untuk bisnis minuman siswa.",
    difficulty: "Lanjutan",
    duration: "40 menit",
    skills: ["Strategi", "Keputusan"],
    icon: BriefcaseBusiness,
    tone: "bg-emerald-50 text-emerald-600",
    task: "Pilih prioritas investasi dengan anggaran terbatas dan jelaskan trade-off keputusanmu.",
    hint: "Nilai dampak, biaya, dan risiko setiap pilihan sebelum memutuskan.",
    majors: ["Manajemen", "Bisnis Digital", "Teknik Industri"],
  },
]

function ChallengeDetail({
  challenge,
  back,
  complete,
  askAI,
  initialCompleted,
}: {
  challenge: Challenge
  back: () => void
  complete: (id: string) => void
  askAI: (context: string) => void
  initialCompleted: boolean
}) {
  const [stage, setStage] = useState<"instruction" | "task" | "result">(
    initialCompleted ? "result" : "instruction",
  )
  const [showHint, setShowHint] = useState(false)
  const [answer, setAnswer] = useState("")
  const [reflection, setReflection] = useState("")
  const Icon = challenge.icon

  if (stage === "result") {
    return (
      <div className="mx-auto max-w-5xl">
        <button
          onClick={back}
          className="mb-5 flex items-center gap-2 text-sm font-bold text-slate-500"
        >
          <ArrowLeft size={16} /> Kembali ke semua challenge
        </button>
        <section className="overflow-hidden rounded-3xl border border-slate-100 bg-white shadow-sm">
          <div className="bg-gradient-to-r from-navy to-indigo-900 p-7 text-white md:p-10">
            <span className="grid size-14 place-items-center rounded-2xl bg-emerald-400 text-navy">
              <Trophy size={28} />
            </span>
            <Badge tone="green">CHALLENGE SELESAI</Badge>
            <h2 className="mt-4 text-3xl font-extrabold">Kerja bagus, Nadia!</h2>
            <p className="mt-2 max-w-2xl text-sm leading-6 text-white/65">
              Kamu menunjukkan pola pikir yang kuat dalam {challenge.area}.
              Hasil ini sudah ditambahkan ke profil eksplorasimu.
            </p>
          </div>
          <div className="grid gap-6 p-6 md:grid-cols-[1.1fr_.9fr] md:p-8">
            <div>
              <h3 className="text-lg font-extrabold">Feedback untukmu</h3>
              <div className="mt-4 rounded-2xl bg-emerald-50 p-5">
                <p className="font-bold text-emerald-800">
                  Kekuatan yang terlihat
                </p>
                <p className="mt-2 text-sm leading-6 text-emerald-700">
                  Kamu mampu mengidentifikasi prioritas, menjelaskan alasan, dan
                  mempertimbangkan kebutuhan pengguna. Ini fondasi yang relevan
                  untuk bidang {challenge.area}.
                </p>
              </div>
              <label className="mt-5 block">
                <span className="field-label">
                  Refleksi: bagian mana yang paling kamu nikmati?
                </span>
                <textarea
                  value={reflection}
                  onChange={(e) => setReflection(e.target.value)}
                  className="field min-h-24 py-3"
                  placeholder="Tuliskan refleksimu..."
                />
              </label>
              <div className="mt-4 flex flex-wrap gap-3">
                <Button
                  onClick={() =>
                    askAI(
                      `Jelaskan hasil challenge ${challenge.area} saya dan sarankan langkah berikutnya.`,
                    )
                  }
                >
                  <Bot size={17} /> Tanya Taktiva AI
                </Button>
                <Button
                  variant="secondary"
                  onClick={() => {
                    setStage("task")
                    setAnswer("")
                  }}
                >
                  <RotateCcw size={16} /> Coba lagi
                </Button>
              </div>
            </div>
            <aside className="rounded-2xl border border-purple/15 bg-purple-pale/50 p-5">
              <p className="mini-label">JURUSAN TERKAIT</p>
              <h3 className="mt-2 font-extrabold">
                Arah yang layak kamu eksplorasi
              </h3>
              <div className="mt-4 space-y-3">
                {challenge.majors.map((major, i) => (
                  <div
                    key={major}
                    className="flex items-center gap-3 rounded-xl bg-white p-3"
                  >
                    <span className="grid size-9 place-items-center rounded-lg bg-purple-pale text-purple">
                      <GraduationCap size={18} />
                    </span>
                    <span className="flex-1 text-sm font-bold">{major}</span>
                    <span className="text-xs font-black text-purple">
                      {91 - i * 5}%
                    </span>
                  </div>
                ))}
              </div>
              <div className="mt-5 flex items-start gap-2 rounded-xl bg-white p-3 text-xs leading-5 text-slate-500">
                <CheckCircle2
                  size={16}
                  className="mt-0.5 shrink-0 text-emerald-500"
                />
                Roadmap diperbarui: eksplorasi satu jurusan terkait challenge
                ini.
              </div>
            </aside>
          </div>
        </section>
      </div>
    )
  }

  return (
    <div className="mx-auto max-w-5xl">
      <button
        onClick={back}
        className="mb-5 flex items-center gap-2 text-sm font-bold text-slate-500"
      >
        <ArrowLeft size={16} /> Kembali ke semua challenge
      </button>
      <div className="mb-6 flex items-center gap-4">
        <span
          className={cn(
            "grid size-14 shrink-0 place-items-center rounded-2xl",
            challenge.tone,
          )}
        >
          <Icon size={26} />
        </span>
        <div>
          <Badge tone="blue">{challenge.area}</Badge>
          <h2 className="mt-1 text-2xl font-extrabold">{challenge.title}</h2>
        </div>
      </div>
      <div className="grid gap-6 lg:grid-cols-[1fr_.38fr]">
        <section className="rounded-3xl border border-slate-100 bg-white p-6 shadow-sm md:p-8">
          <div className="flex items-center gap-3">
            {["Petunjuk", "Tugas", "Hasil"].map((label, i) => (
              <div key={label} className="flex flex-1 items-center gap-2">
                <span
                  className={cn(
                    "grid size-7 place-items-center rounded-full text-xs font-black",
                    (stage === "task" ? i <= 1 : i === 0)
                      ? "bg-purple text-white"
                      : "bg-slate-100 text-slate-400",
                  )}
                >
                  {i + 1}
                </span>
                <span className="hidden text-xs font-bold text-slate-500 sm:block">
                  {label}
                </span>
              </div>
            ))}
          </div>
          {stage === "instruction" ? (
            <div className="mt-8">
              <h3 className="text-xl font-extrabold">Sebelum kamu mulai</h3>
              <p className="mt-3 text-sm leading-7 text-slate-500">
                Bayangkan kamu sedang mengerjakan brief nyata. Fokus kami bukan
                jawaban sempurna, tetapi caramu memahami masalah dan mengambil
                keputusan.
              </p>
              <div className="mt-6 space-y-3">
                {[
                  "Baca konteks dan tujuan dengan teliti.",
                  "Tulis alasan di balik setiap pilihan.",
                  "Gunakan petunjuk jika merasa buntu.",
                ].map((item, i) => (
                  <div
                    key={item}
                    className="flex gap-3 rounded-xl bg-slate-50 p-4 text-sm font-semibold text-slate-600"
                  >
                    <span className="text-purple">0{i + 1}</span>
                    {item}
                  </div>
                ))}
              </div>
              <Button className="mt-7" onClick={() => setStage("task")}>
                Mulai Tantangan <ArrowRight size={17} />
              </Button>
            </div>
          ) : (
            <div className="mt-8">
              <Badge>BRIEF TANTANGAN</Badge>
              <h3 className="mt-4 text-xl font-extrabold">{challenge.task}</h3>
              {challenge.id === "data" && (
                <div className="mt-5 grid grid-cols-3 gap-3">
                  {[
                    ["Roti bakar", "48"],
                    ["Es teh", "76"],
                    ["Rice bowl", "31"],
                  ].map(([label, value]) => (
                    <div
                      key={label}
                      className="rounded-xl bg-soft-blue p-3 text-center"
                    >
                      <p className="text-xl font-black">{value}</p>
                      <p className="text-[10px] text-slate-500">{label}</p>
                    </div>
                  ))}
                </div>
              )}
              <label className="mt-6 block">
                <span className="field-label">Jawaban dan alasanmu</span>
                <textarea
                  value={answer}
                  onChange={(e) => setAnswer(e.target.value)}
                  className="field min-h-40 py-3"
                  placeholder="Jelaskan pendekatanmu di sini..."
                />
              </label>
              {showHint && (
                <div className="mt-4 flex gap-3 rounded-xl bg-amber-50 p-4 text-sm leading-6 text-amber-800">
                  <Lightbulb size={18} className="mt-0.5 shrink-0" />
                  {challenge.hint}
                </div>
              )}
              <div className="mt-6 flex flex-wrap justify-between gap-3">
                <Button variant="ghost" onClick={() => setShowHint(!showHint)}>
                  <Lightbulb size={16} />{" "}
                  {showHint ? "Sembunyikan petunjuk" : "Butuh petunjuk?"}
                </Button>
                <Button
                  disabled={answer.trim().length < 8}
                  onClick={() => {
                    complete(challenge.id)
                    setStage("result")
                  }}
                >
                  Kirim Jawaban <ArrowRight size={17} />
                </Button>
              </div>
            </div>
          )}
        </section>
        <aside className="space-y-4">
          <div className="rounded-2xl border border-slate-100 bg-white p-5 shadow-sm">
            <p className="mini-label">RINGKASAN</p>
            <div className="mt-4 space-y-4 text-sm">
              <p className="flex justify-between text-slate-500">
                Kesulitan{" "}
                <strong className="text-navy">{challenge.difficulty}</strong>
              </p>
              <p className="flex justify-between text-slate-500">
                Durasi{" "}
                <strong className="text-navy">{challenge.duration}</strong>
              </p>
            </div>
            <div className="mt-5 border-t border-slate-100 pt-4">
              <p className="mini-label">SKILL YANG DILATIH</p>
              <div className="mt-2 flex flex-wrap gap-2">
                {challenge.skills.map((skill) => (
                  <Badge key={skill} tone="blue">
                    {skill}
                  </Badge>
                ))}
              </div>
            </div>
          </div>
          <div className="rounded-2xl bg-navy p-5 text-white">
            <Bot size={21} className="text-violet-300" />
            <p className="mt-3 text-sm font-bold">Bingung dengan brief?</p>
            <p className="mt-1 text-xs leading-5 text-white/55">
              Taktiva AI bisa membantumu memahami konteks tanpa memberikan
              jawaban langsung.
            </p>
            <button
              onClick={() =>
                askAI(`Bantu aku memahami brief challenge ${challenge.area}.`)
              }
              className="mt-3 text-xs font-bold text-violet-300"
            >
              Tanya Taktiva AI →
            </button>
          </div>
        </aside>
      </div>
    </div>
  )
}

function Careers({
  completed,
  onComplete,
  askAI,
}: {
  completed: string[]
  onComplete: (id: string) => void
  askAI: (context: string) => void
}) {
  const [active, setActive] = useState<Challenge | null>(null)
  if (active)
    return (
      <ChallengeDetail
        challenge={active}
        back={() => setActive(null)}
        complete={onComplete}
        askAI={askAI}
        initialCompleted={completed.includes(active.id)}
      />
    )

  return (
    <div>
      <section className="rounded-3xl bg-navy p-7 text-white">
        <div className="flex flex-col justify-between gap-6 md:flex-row md:items-end">
          <div className="max-w-2xl">
            <Badge>
              <Zap size={13} /> BELAJAR DENGAN MENCOBA
            </Badge>
            <h2 className="mt-4 text-3xl font-extrabold">
              Karier terasa abstrak? Coba versi mininya.
            </h2>
            <p className="mt-3 text-sm leading-6 text-white/60">
              Selesaikan brief realistis, dapatkan feedback, dan temukan pola
              kekuatan yang memperkaya rekomendasi personalmu.
            </p>
          </div>
          <div className="min-w-52 rounded-2xl bg-white/8 p-4">
            <div className="flex justify-between text-xs font-bold">
              <span>Progres challenge</span>
              <span>{completed.length}/5</span>
            </div>
            <Progress
              value={completed.length * 20}
              className="mt-3 bg-white/10"
            />
          </div>
        </div>
      </section>
      <div className="mt-6 grid gap-5 md:grid-cols-2 xl:grid-cols-3">
        {careerChallenges.map((challenge) => {
          const Icon = challenge.icon
          const isDone = completed.includes(challenge.id)
          return (
            <article
              key={challenge.id}
              className="card-hover flex flex-col rounded-3xl border border-slate-100 bg-white p-6 shadow-sm"
            >
              <div className="flex items-start justify-between">
                <span
                  className={cn(
                    "grid size-12 place-items-center rounded-2xl",
                    challenge.tone,
                  )}
                >
                  <Icon size={23} />
                </span>
                {isDone && (
                  <Badge tone="green">
                    <Check size={12} /> Selesai
                  </Badge>
                )}
              </div>
              <div className="mt-5 flex flex-wrap gap-2">
                <Badge tone="blue">{challenge.area}</Badge>
                <Badge
                  tone={
                    challenge.difficulty === "Lanjutan" ? "amber" : "purple"
                  }
                >
                  {challenge.difficulty}
                </Badge>
              </div>
              <h3 className="mt-4 text-xl font-extrabold">{challenge.title}</h3>
              <p className="mt-2 text-sm leading-6 text-slate-500">
                {challenge.description}
              </p>
              <div className="mt-4 flex flex-wrap gap-2">
                {challenge.skills.map((skill) => (
                  <span
                    key={skill}
                    className="rounded-lg bg-slate-100 px-2.5 py-1 text-[10px] font-bold text-slate-500"
                  >
                    {skill}
                  </span>
                ))}
              </div>
              <div className="mt-auto flex items-center justify-between pt-6 text-xs text-slate-400">
                <span className="flex items-center gap-1">
                  <Clock3 size={13} /> {challenge.duration}
                </span>
                <span>{isDone ? "100%" : "0%"} progres</span>
              </div>
              <Progress value={isDone ? 100 : 0} className="mt-2" />
              <Button
                variant={isDone ? "secondary" : "primary"}
                className="mt-5 w-full"
                onClick={() => setActive(challenge)}
              >
                {isDone ? (
                  <>
                    <RotateCcw size={16} /> Lihat Hasil
                  </>
                ) : (
                  <>
                    <Play size={16} fill="currentColor" /> Mulai Tantangan
                  </>
                )}
              </Button>
            </article>
          )
        })}
      </div>
    </div>
  )
}

function Comparison() {
  const rows = [
    [
      "Kurikulum",
      "Teknologi + bisnis, proyek industri",
      "Fokus sistem, data, dan rekayasa",
    ],
    ["Biaya kuliah", "Rp10–14 jt/semester*", "Rp500 rb–12 jt/semester*"],
    ["Lokasi", "Bandung", "Depok"],
    ["Jalur masuk", "Seleksi mandiri & rapor", "SNBP, SNBT, SIMAK"],
    ["Durasi", "8 semester", "8 semester"],
    ["Beasiswa", "Prestasi, KIP-K, mitra", "KIP-K, PPA, alumni"],
  ]
  return (
    <div>
      <div className="flex flex-col justify-between gap-4 md:flex-row md:items-center">
        <p className="max-w-xl text-sm text-slate-500">
          Data dirangkum untuk membantu eksplorasi. Selalu konfirmasi informasi
          terbaru di situs resmi.
        </p>
        <Button>
          <Download size={16} /> Unduh perbandingan
        </Button>
      </div>
      <div className="mt-6 overflow-hidden rounded-3xl border border-slate-100 bg-white shadow-sm">
        <div className="grid grid-cols-[.7fr_1fr_1fr] bg-navy p-5 text-white">
          <span />
          <div>
            <Badge>OPSI A</Badge>
            <h3 className="mt-3 font-extrabold">
              Sistem Informasi · Telkom University
            </h3>
          </div>
          <div>
            <Badge tone="blue">OPSI B</Badge>
            <h3 className="mt-3 font-extrabold">
              Sistem Informasi · Universitas Indonesia
            </h3>
          </div>
        </div>
        {rows.map(([label, a, b]) => (
          <div
            key={label}
            className="grid grid-cols-[.7fr_1fr_1fr] border-t border-slate-100 p-5 text-sm"
          >
            <strong className="text-slate-500">{label}</strong>
            <span className="pr-4 font-semibold text-navy">{a}</span>
            <span className="font-semibold text-navy">{b}</span>
          </div>
        ))}
      </div>
      <div className="mt-4 flex flex-wrap gap-3">
        <Button variant="secondary">+ Tambah program</Button>
        <Button variant="ghost">
          <FileText size={16} /> Sumber resmi Tel-U ↗
        </Button>
        <Button variant="ghost">
          <FileText size={16} /> Sumber resmi UI ↗
        </Button>
      </div>
    </div>
  )
}

function Roadmap({ aiSuggestions }: { aiSuggestions: string[] }) {
  const [checks, setChecks] = usePS("roadmap-checks", [true, true, false, false, false, false])
  const tasks = [
    ["Hari 1", "Lengkapi profil dan preferensi", "5 menit"],
    ["Hari 3", "Selesaikan asesmen minat & kekuatan", "10 menit"],
    ["Hari 7", "Baca detail 3 jurusan rekomendasi", "20 menit"],
    ["Hari 12", "Coba satu Career Challenge", "30 menit"],
    ["Hari 20", "Bandingkan 2 program pendidikan", "15 menit"],
    ["Hari 30", "Diskusikan shortlist dengan orang tua/guru BK", "30 menit"],
  ]
  const progress = Math.round(
    (checks.filter(Boolean).length / checks.length) * 100,
  )
  return (
    <div className="grid gap-6 xl:grid-cols-[1.3fr_.7fr]">
      <section className="rounded-3xl border border-slate-100 bg-white p-6 shadow-sm">
        <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-center">
          <div>
            <Badge>RENCANA 30 HARI</Badge>
            <h2 className="mt-3 text-2xl font-extrabold">
              Dari eksplorasi ke keputusan
            </h2>
          </div>
          <Button variant="secondary">
            <Download size={16} /> Unduh PDF
          </Button>
        </div>
        <div className="mt-6 flex items-center gap-4 rounded-2xl bg-purple-pale p-4">
          <div className="grid size-14 place-items-center rounded-full bg-purple text-lg font-black text-white">
            {progress}%
          </div>
          <div className="flex-1">
            <div className="flex justify-between text-xs font-bold">
              <span>Progres keseluruhan</span>
              <span>
                {checks.filter(Boolean).length} dari {checks.length} selesai
              </span>
            </div>
            <Progress value={progress} className="mt-2 bg-white" />
          </div>
        </div>
        <div className="mt-6 space-y-3">
          {aiSuggestions.map((suggestion) => (
            <div
              key={suggestion}
              className="flex items-center gap-4 rounded-2xl border border-purple/20 bg-purple-pale/50 p-4"
            >
              <span className="grid size-7 shrink-0 place-items-center rounded-full bg-purple text-white">
                <Sparkles size={14} />
              </span>
              <div className="flex-1">
                <p className="font-bold">{suggestion}</p>
                <p className="mt-1 text-xs text-purple">
                  Saran dari Taktiva AI · ditambahkan ke roadmap
                </p>
              </div>
              <Badge>BARU</Badge>
            </div>
          ))}
          {tasks.map(([day, title, time], i) => (
            <button
              key={day}
              onClick={() =>
                setChecks((s) => s.map((v, idx) => (idx === i ? !v : v)))
              }
              className={cn(
                "flex w-full items-center gap-4 rounded-2xl border p-4 text-left transition",
                checks[i]
                  ? "border-emerald-100 bg-emerald-50/60"
                  : "border-slate-100 hover:border-purple/20",
              )}
            >
              <span
                className={cn(
                  "grid size-7 shrink-0 place-items-center rounded-full border",
                  checks[i]
                    ? "border-emerald-500 bg-emerald-500 text-white"
                    : "border-slate-300 text-transparent",
                )}
              >
                <Check size={15} />
              </span>
              <div className="flex-1">
                <p
                  className={cn(
                    "font-bold",
                    checks[i] && "text-slate-400 line-through",
                  )}
                >
                  {title}
                </p>
                <p className="mt-1 text-xs text-slate-400">
                  {day} · {time}
                </p>
              </div>
              <ChevronRight size={17} className="text-slate-300" />
            </button>
          ))}
        </div>
      </section>
      <aside className="space-y-5">
        <div className="rounded-3xl bg-navy p-6 text-white">
          <Target className="text-violet-300" />
          <h3 className="mt-4 text-xl font-extrabold">Fokus minggu ini</h3>
          <p className="mt-2 text-sm leading-6 text-white/60">
            Pahami perbedaan Sistem Informasi dan Teknik Industri melalui
            kurikulum nyata.
          </p>
          <div className="mt-5 rounded-xl bg-white/8 p-4 text-sm font-bold">
            2 dari 3 milestone selesai
          </div>
        </div>
        <div className="rounded-3xl border border-slate-100 bg-white p-6 shadow-sm">
          <h3 className="font-extrabold">Butuh dukungan?</h3>
          <p className="mt-2 text-sm leading-6 text-slate-500">
            Bawa ringkasan roadmap ini saat berbicara dengan guru BK atau orang
            tua.
          </p>
          <Button variant="secondary" className="mt-4 w-full">
            <MessageCircle size={16} /> Siapkan ringkasan
          </Button>
        </div>
      </aside>
    </div>
  )
}

function Saved({ go }: { go: (p: AppPage) => void }) {
  const [tab, setTab] = useState("Jurusan")
  return (
    <div>
      <div className="flex gap-2 overflow-x-auto">
        {["Jurusan", "Universitas", "Karier", "Skenario"].map((t) => (
          <button
            key={t}
            onClick={() => setTab(t)}
            className={cn(
              "rounded-xl px-4 py-2.5 text-sm font-bold",
              tab === t
                ? "bg-navy text-white"
                : "border border-slate-200 bg-white text-slate-500",
            )}
          >
            {t}
          </button>
        ))}
      </div>
      {tab === "Jurusan" ? (
        <div className="mt-6 grid gap-5 md:grid-cols-3">
          {majors.map((m) => (
            <article
              key={m.name}
              className="rounded-3xl border border-slate-100 bg-white p-6 shadow-sm"
            >
              <div className="flex justify-between">
                <GraduationCap className="text-purple" />
                <BookmarkCheck className="text-purple" fill="currentColor" />
              </div>
              <h3 className="mt-4 text-lg font-extrabold">{m.name}</h3>
              <p className="mt-2 text-sm text-slate-500">{m.desc}</p>
              <Button
                variant="secondary"
                className="mt-5 w-full"
                onClick={() => go("recommendations")}
              >
                Buka detail
              </Button>
            </article>
          ))}
        </div>
      ) : (
        <div className="mt-6 grid min-h-80 place-items-center rounded-3xl border border-dashed border-slate-200 bg-white text-center">
          <div>
            <span className="mx-auto grid size-14 place-items-center rounded-2xl bg-slate-100 text-slate-400">
              <Bookmark size={24} />
            </span>
            <h3 className="mt-4 font-extrabold">
              Belum ada {tab.toLowerCase()} tersimpan
            </h3>
            <p className="mt-2 text-sm text-slate-400">
              Simpan pilihan yang menarik agar mudah dibandingkan nanti.
            </p>
            <Button
              className="mt-5"
              onClick={() => go(tab === "Karier" ? "careers" : "majors")}
            >
              Mulai eksplorasi
            </Button>
          </div>
        </div>
      )}
    </div>
  )
}

function Profile({ profile, saveProfile, logout, completedChallenges, emailReadOnly = false }: { profile: StudentProfile; saveProfile: (p: StudentProfile) => Promise<string | null>; logout: () => void; completedChallenges: number; emailReadOnly?: boolean }) {
  const [draft, setDraft] = useState<StudentProfile>(profile)
  const [toast, setToast] = useState("")
  const [saving, setSaving] = useState(false)
  useEffect(() => setDraft(profile), [profile])
  const update = <K extends keyof StudentProfile>(key: K, value: StudentProfile[K]) => setDraft(current => ({ ...current, [key]: value }))
  const save = async () => {
    if (!draft.name.trim()) { setToast("Nama lengkap wajib diisi."); return }
    if (!draft.email.trim()) { setToast("Email tidak boleh kosong."); return }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(draft.email.trim())) { setToast("Format email belum valid."); return }
    setSaving(true)
    const result = await saveProfile({ ...draft, name: draft.name.trim(), email: draft.email.trim().toLowerCase(), school: draft.school.trim() })
    setSaving(false)
    setToast(result || (isSupabaseConfigured ? "Profil berhasil disimpan ke akun online." : "Profil berhasil disimpan di browser ini."))
    window.setTimeout(() => setToast(""), 4000)
  }
  const initials = draft.name.trim().split(/\s+/).slice(0,2).map(part => part[0]?.toUpperCase() || "").join("") || "TA"
  const input = (label: string, value: string, onChange: (v: string) => void, props: {type?: string; disabled?: boolean; placeholder?: string} = {}) => <label className="block"><span className="field-label">{label}</span><input className="field" value={value} onChange={e => onChange(e.target.value)} type={props.type || "text"} disabled={props.disabled} placeholder={props.placeholder}/></label>
  return <div className="grid gap-6 xl:grid-cols-[1fr_.55fr]"><section className="rounded-3xl border border-slate-100 bg-white p-6 shadow-sm"><div className="flex items-center gap-4 border-b border-slate-100 pb-6"><span className="grid size-16 place-items-center rounded-2xl bg-gradient-to-br from-purple to-violet-400 text-xl font-black text-white">{initials}</span><div className="min-w-0"><h2 className="text-xl font-extrabold">{draft.name || "Profil siswa"}</h2><p className="text-sm text-slate-400">{draft.classLevel || "Siswa"} · {draft.school || "Sekolah belum diisi"}</p></div><Badge tone="green">{isSupabaseConfigured ? "ONLINE" : "DEMO"}</Badge></div>
    <h3 className="mt-6 font-extrabold">Informasi pribadi</h3><div className="mt-4 grid gap-4 sm:grid-cols-2">{input("Nama lengkap", draft.name, v => update("name",v), {placeholder:"Nama lengkap"})}{input("Email", draft.email, v => update("email",v), {type:"email", disabled: emailReadOnly})}{emailReadOnly && <p className="-mt-2 text-xs text-slate-400 sm:col-span-2">Email akun dikelola oleh Supabase Auth dan tidak dapat diubah dari formulir profil ini.</p>}{input("Sekolah", draft.school, v => update("school",v), {placeholder:"Nama sekolah"})}<label className="block"><span className="field-label">Kelas / status</span><select className="field" value={draft.classLevel} onChange={e => update("classLevel",e.target.value)}><option>Kelas XII</option><option>Kelas XI</option><option>Gap year</option><option>Lulusan SMA/SMK</option></select></label></div>
    <h3 className="mt-7 font-extrabold">Preferensi pendidikan</h3><div className="mt-4 grid gap-4 sm:grid-cols-2"><label className="block"><span className="field-label">Lokasi pilihan</span><select className="field" value={draft.location} onChange={e => update("location",e.target.value)}>{["Belum ditentukan","Bandung","Jabodetabek","Yogyakarta","Di mana saja"].map(x=><option key={x}>{x}</option>)}</select></label><label className="block"><span className="field-label">Rentang anggaran</span><select className="field" value={draft.budget} onChange={e => update("budget",e.target.value)}>{["Belum ditentukan","< Rp5 juta/semester","Rp5–15 juta/semester","Rp15–30 juta/semester","Fleksibel"].map(x=><option key={x}>{x}</option>)}</select></label></div>
    <h3 className="mt-7 font-extrabold">Minat, kekuatan, dan aspirasi</h3><p className="mt-1 text-sm text-slate-500">Ubah pilihan di bawah, pisahkan dengan koma.</p><div className="mt-4 grid gap-4">{input("Minat", draft.interests.join(", "), v => update("interests",v.split(",").map(x=>x.trim()).filter(Boolean)), {placeholder:"Teknologi, bisnis, desain"})}{input("Kekuatan", draft.strengths.join(", "), v => update("strengths",v.split(",").map(x=>x.trim()).filter(Boolean)), {placeholder:"Matematika, komunikasi"})}{input("Aspirasi", draft.aspirations.join(", "), v => update("aspirations",v.split(",").map(x=>x.trim()).filter(Boolean)), {placeholder:"Membangun produk digital"})}</div>
    <div className="mt-7 flex flex-wrap gap-3"><Button disabled={saving} onClick={() => void save()}><Check size={16}/> {saving ? "Menyimpan..." : "Simpan perubahan"}</Button><Button variant="secondary" onClick={() => setDraft(profile)}><RotateCcw size={16}/> Batalkan perubahan</Button></div>{toast && <div role="status" className="mt-4 flex items-center gap-3 rounded-2xl bg-navy px-5 py-4 text-sm font-bold text-white"><CheckCircle2 className="text-emerald-400" size={19}/>{toast}</div>}</section>
    <aside className="space-y-5"><div className="rounded-3xl bg-navy p-6 text-white"><div className="flex items-center justify-between"><span className="grid size-10 place-items-center rounded-xl bg-white/10 text-violet-300"><Trophy size={20}/></span><Badge tone="green">PROFIL SKILL</Badge></div><h3 className="mt-4 font-extrabold">{completedChallenges} Career Challenge selesai</h3><p className="mt-2 text-xs leading-5 text-white/55">Hasil challenge memperkaya insight keterampilan, bukan menentukan pilihan karier secara mutlak.</p><Progress value={Math.min(100,completedChallenges*20)} className="mt-4 bg-white/10"/></div>
    <div className="rounded-3xl border border-slate-100 bg-white p-6 shadow-sm"><h3 className="font-extrabold">Notifikasi</h3>{["Pengingat roadmap","Rekomendasi baru","Update biaya kuliah"].map((x,i)=><label key={x} className="mt-5 flex items-center justify-between text-sm font-semibold text-slate-600">{x}<input type="checkbox" defaultChecked={i<2} className="size-4 accent-purple"/></label>)}</div>
    <div className="rounded-3xl border border-slate-100 bg-white p-6 shadow-sm"><h3 className="flex items-center gap-2 font-extrabold"><ShieldCheck size={18} className="text-purple"/> Privasi & keamanan</h3><p className="mt-3 text-sm leading-6 text-slate-500">{isSupabaseConfigured ? "Akun menggunakan Supabase Auth dan profil disimpan di database online dengan Row Level Security." : "Mode demo lokal: profil disimpan di browser perangkat ini. Aktifkan Supabase untuk sinkronisasi online."}</p><Button variant="secondary" className="mt-6 w-full text-rose-600" onClick={logout}><LogOut size={16}/> Keluar dari akun</Button></div></aside></div>
}

type ChatMessage = {
  id: number
  from: "ai" | "user"
  text: string
}

function getAIReply(prompt: string) {
  const lower = prompt.toLowerCase()
  if (lower.includes("biaya"))
    return "Untuk pilihanmu, rentang biaya Sistem Informasi umumnya sekitar Rp8–18 juta per semester. Angka ini perlu diverifikasi di situs resmi kampus. Aku bisa bantu membandingkan jalur PTN, PTS, dan vokasi sesuai anggaranmu."
  if (lower.includes("challenge") || lower.includes("hasil"))
    return "Hasil challenge menunjukkan kamu cukup kuat dalam memecah masalah dan menjelaskan alasan. Aku sarankan mencoba challenge Data Analysis berikutnya, lalu mengeksplorasi Sistem Informasi dan Statistika agar pola kekuatanmu makin jelas."
  if (lower.includes("banding") || lower.includes("sistem informasi"))
    return "Sistem Informasi memadukan teknologi dan bisnis, Teknik Industri berfokus pada optimasi sistem, sedangkan Bisnis Digital lebih kuat di strategi pasar dan pertumbuhan. Berdasarkan profilmu, Sistem Informasi paling dekat dengan kombinasi minat teknologi dan komunikasi."
  if (lower.includes("kampus") || lower.includes("universitas"))
    return "Mulailah dari tiga filter: kecocokan kurikulum, biaya total, dan jalur masuk. Untuk wilayah Bandung, kamu bisa membandingkan program di Telkom University, ITB, dan beberapa politeknik—selalu cek sumber resmi untuk detail terbaru."
  return "Aku bisa membantumu menghubungkan minat, hasil challenge, jurusan, jalur kampus, dan biaya pendidikan. Ceritakan pilihan yang sedang kamu pertimbangkan, lalu kita uraikan trade-off-nya bersama."
}

function Chatbot({
  open,
  show,
  close,
  starter,
  clearStarter,
  addRoadmap,
}: {
  open: boolean
  show: () => void
  close: () => void
  starter: string
  clearStarter: () => void
  addRoadmap: (suggestion: string) => void
}) {
  const [messages, setMessages] = usePS<ChatMessage[]>("chat", [
    {
      id: 1,
      from: "ai",
      text: "Hai, Nadia! Aku Taktiva AI. Aku bisa membantu mengeksplorasi jurusan, karier, biaya pendidikan, atau membaca hasil Career Challenge-mu.",
    },
  ])
  const [input, setInput] = useState("")
  const [typing, setTyping] = useState(false)
  const [roadmapAdded, setRoadmapAdded] = useState(false)

  const send = (text = input) => {
    const clean = text.trim()
    if (!clean || typing) return
    setMessages((current) => [
      ...current,
      { id: Date.now(), from: "user", text: clean },
    ])
    setInput("")
    setTyping(true)
    const read = (k: string) => {
      try {
        return JSON.parse(localStorage.getItem("taktiva:" + k) || "[]")
      } catch {
        return []
      }
    }
    const history = [...messages, { id: 0, from: "user", text: clean }]
      .slice(-8)
      .map((m) => ({ role: m.from === "ai" ? "assistant" : "user", content: m.text }))
    const reply = async () => {
      try {
        const res = await fetch("/api/chat", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            messages: history,
            context: { savedMajors: read("saved-majors"), completedChallenges: read("done-challenges") },
          }),
        })
        const data = await res.json()
        if (res.ok && data.reply) return data.reply as string
      } catch {}
      return getAIReply(clean) + "\n\n(Respons simulasi — mode demo)"
    }
    reply().then((text) => {
      setMessages((current) => [...current, { id: Date.now() + 1, from: "ai", text }])
      setTyping(false)
    })
  }

  useEffect(() => {
    if (!starter) return
    send(starter)
    clearStarter()
    // A contextual starter should be consumed only once.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [starter])

  return (
    <>
      <button
        aria-label="Buka Taktiva AI"
        onClick={open ? close : show}
        className={cn(
          "fixed bottom-5 right-5 z-40 grid size-14 place-items-center rounded-2xl bg-purple text-white shadow-xl shadow-purple/30 transition hover:-translate-y-1 lg:bottom-7 lg:right-7",
          open && "pointer-events-none scale-90 opacity-0",
        )}
      >
        <Bot size={25} />
        <span className="absolute right-0 top-0 size-3 rounded-full border-2 border-white bg-emerald-400" />
      </button>
      {!open && (
        <button
          onClick={show}
          className="fixed bottom-8 right-24 z-30 hidden rounded-xl bg-navy px-3 py-2 text-xs font-bold text-white shadow-lg xl:block"
        >
          Tanya Taktiva AI
        </button>
      )}
      <div
        className={cn(
          "fixed inset-x-3 bottom-3 z-50 flex h-[min(680px,calc(100vh-24px))] flex-col overflow-hidden rounded-3xl border border-slate-200 bg-white shadow-2xl transition-all sm:inset-x-auto sm:bottom-6 sm:right-6 sm:w-[410px]",
          open
            ? "translate-y-0 opacity-100"
            : "pointer-events-none translate-y-8 opacity-0",
        )}
      >
        <header className="flex items-center gap-3 bg-navy p-4 text-white">
          <span className="relative grid size-11 place-items-center rounded-xl bg-purple">
            <Bot size={22} />
            <span className="absolute -right-0.5 -top-0.5 size-3 rounded-full border-2 border-navy bg-emerald-400" />
          </span>
          <div className="flex-1">
            <h3 className="font-extrabold">Taktiva AI</h3>
            <p className="text-[11px] text-white/55">
              Mode demo · respons simulasi, bukan LLM sungguhan
            </p>
          </div>
          <button
            aria-label="Tutup chat"
            onClick={close}
            className="grid size-9 place-items-center rounded-lg hover:bg-white/10"
          >
            <X size={19} />
          </button>
        </header>
        <div className="border-b border-slate-100 px-4 py-3">
          <p className="mini-label">COBA TANYAKAN</p>
          <div className="mt-2 flex gap-2 overflow-x-auto pb-1">
            {[
              "Jurusan yang cocok untukku",
              "Jelaskan hasil challenge",
              "Bandingkan biaya kuliah",
            ].map((prompt) => (
              <button
                key={prompt}
                onClick={() => send(prompt)}
                className="whitespace-nowrap rounded-full border border-purple/15 bg-purple-pale px-3 py-1.5 text-[10px] font-bold text-purple"
              >
                {prompt}
              </button>
            ))}
          </div>
        </div>
        <div className="flex-1 space-y-4 overflow-y-auto bg-slate-50/70 p-4">
          {messages.map((message) => (
            <div
              key={message.id}
              className={cn(
                "flex",
                message.from === "user" ? "justify-end" : "justify-start",
              )}
            >
              <div
                className={cn(
                  "max-w-[84%] rounded-2xl px-4 py-3 text-sm leading-6",
                  message.from === "user"
                    ? "rounded-br-sm bg-purple text-white"
                    : "rounded-bl-sm border border-slate-100 bg-white text-slate-600 shadow-sm",
                )}
              >
                {message.text}
              </div>
            </div>
          ))}
          {typing && (
            <div className="flex gap-1 rounded-2xl rounded-bl-sm bg-white p-4 shadow-sm w-fit">
              {[0, 1, 2].map((i) => (
                <span
                  key={i}
                  className="typing-dot size-2 rounded-full bg-slate-300"
                  style={{ animationDelay: `${i * 140}ms` }}
                />
              ))}
            </div>
          )}
          {messages.length > 2 && !roadmapAdded && (
            <button
              onClick={() => {
                addRoadmap(
                  "Coba challenge Data Analysis dan refleksikan hasilnya",
                )
                setRoadmapAdded(true)
              }}
              className="flex w-full items-center gap-3 rounded-2xl border border-purple/20 bg-purple-pale p-3 text-left"
            >
              <span className="grid size-9 place-items-center rounded-xl bg-purple text-white">
                <Sparkles size={17} />
              </span>
              <span className="flex-1 text-xs font-bold text-navy">
                Tambahkan saran challenge ke roadmap
              </span>
              <ChevronRight size={16} className="text-purple" />
            </button>
          )}
          {roadmapAdded && (
            <p className="flex items-center gap-2 text-xs font-bold text-emerald-600">
              <CheckCircle2 size={15} /> Saran berhasil ditambahkan ke roadmap
            </p>
          )}
        </div>
        <form
          className="flex items-end gap-2 border-t border-slate-100 bg-white p-3"
          onSubmit={(e) => {
            e.preventDefault()
            send()
          }}
        >
          <textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault()
                send()
              }
            }}
            className="field min-h-11 flex-1 resize-none py-3"
            rows={1}
            placeholder="Tanyakan tentang masa depanmu..."
          />
          <button
            type="submit"
            disabled={!input.trim() || typing}
            className="grid size-11 shrink-0 place-items-center rounded-xl bg-purple text-white disabled:opacity-40"
          >
            <Send size={18} />
          </button>
        </form>
        <p className="pb-2 text-center text-[9px] text-slate-400">
          AI dapat keliru. Verifikasi informasi penting di sumber resmi.
        </p>
      </div>
    </>
  )
}

function AppShell({ profile, saveProfile, logout }: { profile: StudentProfile; saveProfile: (p: StudentProfile) => Promise<string | null>; logout: () => void }) {
  const [page, setPage] = usePS<AppPage>("page", "dashboard")
  const [menu, setMenu] = useState(false)
  const [chatOpen, setChatOpen] = useState(false)
  const [chatStarter, setChatStarter] = useState("")
  const [completedChallenges, setCompletedChallenges] = usePS<string[]>("done-challenges", [])
  const [aiSuggestions, setAiSuggestions] = usePS<string[]>("ai-suggestions", [])

  const askAI = (context = "") => {
    setChatStarter(context)
    setChatOpen(true)
  }
  const completeChallenge = (id: string) => {
    setCompletedChallenges((current) =>
      current.includes(id) ? current : [...current, id],
    )
    const challenge = careerChallenges.find((item) => item.id === id)
    if (challenge) {
      const suggestion = `Eksplorasi ${challenge.majors[0]} dari hasil challenge ${challenge.area}`
      setAiSuggestions((current) =>
        current.includes(suggestion) ? current : [...current, suggestion],
      )
    }
  }
  let content: ReactNode
  if (page === "dashboard") content = <Dashboard go={setPage} />
  else if (page === "majors") content = <Majors go={setPage} />
  else if (page === "assessment")
    content = <Assessment done={() => setPage("recommendations")} />
  else if (page === "recommendations")
    content = (
      <Recommendations compare={() => setPage("comparison")} askAI={askAI} />
    )
  else if (page === "simulator")
    content = <Simulator compare={() => setPage("comparison")} />
  else if (page === "careers")
    content = (
      <Careers
        completed={completedChallenges}
        onComplete={completeChallenge}
        askAI={askAI}
      />
    )
  else if (page === "comparison") content = <Comparison />
  else if (page === "roadmap")
    content = <Roadmap aiSuggestions={aiSuggestions} />
  else if (page === "saved") content = <Saved go={setPage} />
  else
    content = (
      <Profile
        profile={profile}
        saveProfile={saveProfile}
        logout={logout}
        completedChallenges={completedChallenges.length}
        emailReadOnly={isSupabaseConfigured}
      />
    )
  return (
    <div className="min-h-screen bg-app">
      <Sidebar
        page={page}
        setPage={setPage}
        open={menu}
        close={() => setMenu(false)}
        openChat={() => askAI()}
      />
      <div className="lg:pl-72">
        <Topbar page={page} menu={() => setMenu(true)} profile={profile} openProfile={() => setPage("profile")} />
        <main className="mx-auto max-w-[1500px] p-5 lg:p-8">{content}</main>
      </div>
      <Chatbot
        open={chatOpen}
        show={() => setChatOpen(true)}
        close={() => setChatOpen(false)}
        starter={chatStarter}
        clearStarter={() => setChatStarter("")}
        addRoadmap={(suggestion) =>
          setAiSuggestions((current) =>
            current.includes(suggestion) ? current : [...current, suggestion],
          )
        }
      />
    </div>
  )
}

export default function App() {
  const [view, setView] = usePS<PublicView | "app">("view", "landing")
  const [accounts, setAccounts] = usePS<DemoAccount[]>("demo-accounts", [])
  const [currentUserId, setCurrentUserId] = usePS<string | null>("current-user-id", null)
  const [remoteUserId, setRemoteUserId] = useState<string | null>(null)
  const [remoteProfile, setRemoteProfile] = useState<StudentProfile | null>(null)
  const [authReady, setAuthReady] = useState(!isSupabaseConfigured)
  const [authError, setAuthError] = useState("")

  const loadRemoteProfile = async (user: { id: string; email?: string; user_metadata?: Record<string, unknown> }) => {
    if (!supabase) return
    const { data, error } = await supabase.from("profiles").select("*").eq("id", user.id).maybeSingle()
    if (error) { setAuthError("Tidak dapat memuat profil. Pastikan tabel dan kebijakan RLS Supabase sudah dibuat."); return }
    const metadataName = typeof user.user_metadata?.full_name === "string" ? user.user_metadata.full_name : ""
    const fallback = emptyProfile(metadataName, user.email || "")
    const profile: StudentProfile = data ? {
      name: data.name || metadataName, email: user.email || data.email || "", school: data.school || "",
      classLevel: data.class_level || "Kelas XII", interests: data.interests || [], strengths: data.strengths || [],
      aspirations: data.aspirations || [], location: data.location || "Belum ditentukan", budget: data.budget || "Belum ditentukan",
    } : fallback
    if (!data) {
      const { error: insertError } = await supabase.from("profiles").upsert({
        id: user.id, name: profile.name, email: profile.email, school: profile.school,
        class_level: profile.classLevel, interests: profile.interests, strengths: profile.strengths,
        aspirations: profile.aspirations, location: profile.location, budget: profile.budget,
      })
      if (insertError) { setAuthError("Profil belum dapat dibuat di database. Jalankan supabase/schema.sql di SQL Editor."); return }
    }
    setRemoteUserId(user.id); setRemoteProfile(profile); setAuthError("")
  }

  useEffect(() => {
    if (!supabase) return
    let alive = true
    const init = async () => {
      const { data, error } = await supabase!.auth.getSession()
      if (!alive) return
      if (error) setAuthError(error.message)
      if (data.session?.user) {
        await loadRemoteProfile(data.session.user)
        if (alive) setView("app")
      } else {
        setRemoteUserId(null); setRemoteProfile(null)
      }
      if (alive) setAuthReady(true)
    }
    void init()
    const { data: { subscription } } = supabase.auth.onAuthStateChange((event, session) => {
      if (!alive) return
      if (event === "PASSWORD_RECOVERY" && session?.user) {
        setRemoteUserId(session.user.id)
        setView("reset-password")
        return
      }
      if (session?.user) {
        // Defer database access outside the auth callback to avoid blocking auth state processing.
        setTimeout(() => { if (alive) void loadRemoteProfile(session.user).then(() => { if (alive) setView("app") }) }, 0)
      } else {
        setRemoteUserId(null); setRemoteProfile(null)
        if (alive) setView(current => current === "login" || current === "register" ? current : "landing")
      }
    })
    return () => { alive = false; subscription.unsubscribe() }
  }, [])

  const account = isSupabaseConfigured
    ? (remoteUserId && remoteProfile ? { id: remoteUserId, profile: remoteProfile } : null)
    : (accounts.find(item => item.id === currentUserId) || null)

  const updateProfile = async (profile: StudentProfile): Promise<string | null> => {
    if (isSupabaseConfigured && supabase) {
      if (!remoteUserId) return "Sesi akun tidak ditemukan. Silakan masuk kembali."
      const normalized = { ...profile, email: account?.profile.email || profile.email }
      const { error } = await supabase.from("profiles").upsert({
        id: remoteUserId, name: normalized.name, email: normalized.email, school: normalized.school,
        class_level: normalized.classLevel, interests: normalized.interests, strengths: normalized.strengths,
        aspirations: normalized.aspirations, location: normalized.location, budget: normalized.budget,
      })
      if (error) return `Profil gagal disimpan: ${error.message}`
      setRemoteProfile(normalized)
      return null
    }
    if (!account) return "Sesi akun tidak ditemukan. Silakan masuk kembali."
    const normalizedEmail = profile.email.trim().toLowerCase()
    if (accounts.some(item => item.id !== account.id && item.profile.email.toLowerCase() === normalizedEmail)) return "Email ini sudah digunakan oleh akun lain di browser ini."
    setAccounts(current => current.map(item => item.id === account.id ? { ...item, profile: { ...profile, email: normalizedEmail } } : item))
    return null
  }

  const login = async (email: string, password: string) => {
    if (isSupabaseConfigured && supabase) {
      const { data, error } = await supabase.auth.signInWithPassword({ email, password })
      if (error) return "Email atau kata sandi tidak cocok, atau akun belum diverifikasi."
      if (!data.user) return "Login belum berhasil. Coba lagi."
      await loadRemoteProfile(data.user)
      if (!remoteProfile) { /* profile state updates asynchronously; profile will load on auth event */ }
      setView("app")
      return null
    }
    const found = accounts.find(item => item.profile.email.toLowerCase() === email)
    if (!found) return "Akun tidak ditemukan di browser ini. Daftar terlebih dahulu pada perangkat ini."
    if (found.passwordHash !== await hashPassword(password)) return "Email atau kata sandi tidak cocok."
    setCurrentUserId(found.id); setView("app"); return null
  }

  const register = async (data: { name: string; email: string; password: string; school: string; classLevel: string }) => {
    if (isSupabaseConfigured && supabase) {
      const { data: result, error } = await supabase.auth.signUp({
        email: data.email, password: data.password,
        options: { data: { full_name: data.name, school: data.school, class_level: data.classLevel } },
      })
      if (error) return error.message
      if (!result.session || !result.user) return "SUCCESS:Pendaftaran berhasil. Periksa email untuk verifikasi, lalu masuk ke Taktiva."
      const profile = { ...emptyProfile(data.name, data.email), school: data.school, classLevel: data.classLevel }
      const { error: profileError } = await supabase.from("profiles").upsert({
        id: result.user.id, name: profile.name, email: profile.email, school: profile.school,
        class_level: profile.classLevel, interests: [], strengths: [], aspirations: [], location: profile.location, budget: profile.budget,
      })
      if (profileError) return "Akun dibuat, tetapi profil belum tersimpan. Pastikan schema Supabase sudah dijalankan."
      setRemoteUserId(result.user.id); setRemoteProfile(profile); setView("onboarding"); return null
    }
    if (accounts.some(item => item.profile.email.toLowerCase() === data.email)) return "Email ini sudah terdaftar di browser ini. Silakan masuk."
    const id = typeof crypto.randomUUID === "function" ? crypto.randomUUID() : `${Date.now()}-${Math.random()}`
    const profile = { ...emptyProfile(data.name, data.email), school: data.school, classLevel: data.classLevel }
    const next: DemoAccount = { id, passwordHash: await hashPassword(data.password), profile }
    setAccounts(current => [...current, next]); setCurrentUserId(id); setView("onboarding"); return null
  }

  const resetPassword = async (password: string): Promise<string | null> => {
    if (!supabase) return "Supabase belum dikonfigurasi."
    const { error } = await supabase.auth.updateUser({ password })
    if (error) return error.message
    const { data } = await supabase.auth.getUser()
    if (data.user) await loadRemoteProfile(data.user)
    setView("app")
    return null
  }

  const logout = async () => {
    if (isSupabaseConfigured && supabase) await supabase.auth.signOut()
    setRemoteUserId(null); setRemoteProfile(null); setCurrentUserId(null); setView("landing")
  }

  if (isSupabaseConfigured && !authReady) return <div className="grid min-h-screen place-items-center bg-soft-blue p-6"><div className="rounded-2xl bg-white p-8 text-center shadow-sm"><div className="mx-auto mb-4 size-8 animate-spin rounded-full border-4 border-purple/20 border-t-purple"/><p className="font-bold text-navy">Memuat akun Taktiva...</p></div></div>
  if (view === "landing") return <Landing go={setView} />
  if (view === "reset-password") return <ResetPassword onUpdate={resetPassword} go={setView} />
  if (view === "login" || view === "register") return <><Auth mode={view} go={setView} onLogin={login} onRegister={register} />{authError && <p role="alert" className="fixed bottom-4 left-4 right-4 rounded-xl bg-rose-50 p-3 text-sm text-rose-700">{authError}</p>}</>
  if (view === "onboarding") {
    if (!account) { setView("register"); return null }
    return <Onboarding profile={account.profile} saveProfile={updateProfile} finish={() => setView("app")} />
  }
  if (!account) return <><Auth mode="login" go={setView} onLogin={login} onRegister={register} />{authError && <p role="alert" className="fixed bottom-4 left-4 right-4 rounded-xl bg-rose-50 p-3 text-sm text-rose-700">{authError}</p>}</>
  return <AppShell profile={account.profile} saveProfile={updateProfile} logout={() => { void logout() }} />
}
