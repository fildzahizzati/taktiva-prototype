-- Jalankan di Supabase Dashboard > SQL Editor.
-- Setiap siswa hanya dapat membaca/mengubah baris profil miliknya sendiri.
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  name text not null default '',
  email text not null default '',
  school text not null default '',
  class_level text not null default 'Kelas XII',
  interests text[] not null default '{}',
  strengths text[] not null default '{}',
  aspirations text[] not null default '{}',
  location text not null default 'Belum ditentukan',
  budget text not null default 'Belum ditentukan',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.profiles enable row level security;
drop policy if exists "Students can read own profile" on public.profiles;
create policy "Students can read own profile" on public.profiles
  for select to authenticated using ((select auth.uid()) = id);
drop policy if exists "Students can insert own profile" on public.profiles;
create policy "Students can insert own profile" on public.profiles
  for insert to authenticated with check ((select auth.uid()) = id);
drop policy if exists "Students can update own profile" on public.profiles;
create policy "Students can update own profile" on public.profiles
  for update to authenticated using ((select auth.uid()) = id) with check ((select auth.uid()) = id);

create or replace function public.set_profile_updated_at()
returns trigger language plpgsql as $$
begin
  new.updated_at = now();
  return new;
end;
$$;
drop trigger if exists set_profile_updated_at on public.profiles;
create trigger set_profile_updated_at before update on public.profiles
for each row execute function public.set_profile_updated_at();
