// Netlify Function (v2). Kunci API hanya dibaca di server.
const SYSTEM = `Kamu adalah Taktiva AI, asisten eksplorasi pendidikan dan karier untuk siswa SMA kelas XII di Indonesia.
Gunakan Bahasa Indonesia yang ramah dan sesuai usia. Jangan memberi prediksi karier atau peluang diterima yang pasti.
Jangan mengarang biaya kuliah, beasiswa, syarat masuk, atau kebijakan resmi; arahkan ke situs resmi kampus atau portal pemerintah bila butuh data terbaru.
Bedakan fakta yang terverifikasi dari saran umum. Jangan mempermalukan siswa soal nilai, kemampuan, atau kondisi keuangan.
Kamu bukan konselor atau psikolog berlisensi. Berikan langkah berikutnya yang konkret dan singkat.`

const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), { status, headers: { "content-type": "application/json" } })

export default async (req: Request) => {
  if (req.method !== "POST") return json({ error: "Method not allowed" }, 405)
  const key = process.env.LLM_API_KEY
  if (!key) return json({ demo: true, error: "LLM belum dikonfigurasi" }, 503)
  let body: any = {}
  try {
    body = await req.json()
  } catch {}
  const { messages = [], context = {} } = body
  const safe = (Array.isArray(messages) ? messages : []).slice(-8).map((m: any) => ({
    role: m.role === "assistant" ? "assistant" : "user",
    content: String(m.content || "").slice(0, 2000),
  }))
  try {
    const r = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: { "content-type": "application/json", "x-api-key": key, "anthropic-version": "2023-06-01" },
      body: JSON.stringify({
        model: process.env.LLM_MODEL || "claude-sonnet-5-5",
        max_tokens: 700,
        system: `${SYSTEM}\n\nKonteks siswa (opsional): ${JSON.stringify(context).slice(0, 800)}`,
        messages: safe,
      }),
    })
    const data: any = await r.json()
    if (!r.ok) return json({ error: "Layanan LLM gagal" }, 502)
    return json({ reply: data.content?.map((c: any) => c.text || "").join("") })
  } catch {
    return json({ error: "Kesalahan server" }, 500)
  }
}

export const config = { path: "/api/chat" }
